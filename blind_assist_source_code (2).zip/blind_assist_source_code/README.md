# AI-Powered Object Detection & Voice Assistance Capstone

A complete MATLAB pipeline that trains a **YOLOv4** object detector on an
everyday-objects dataset and wraps it in an **assistance layer** that
turns detections into spoken, prioritized natural-language guidance —
built as groundwork for an assistive-technology use case (e.g. helping a
visually impaired user understand what's around them).

---

## Project Structure

```
capstone_matlab_project/
├── main_capstone.m                     Main controller (menu + pipeline runner)
├── run_project.m                       Optional one-line launcher
│
├── config/
│   └── project_config.m                All paths, classes, and hyperparameters
│
├── dataset/everydayObjectDataset/      Your raw images go here
├── models/                             trainedYOLOv4.mat lands here after training
├── results/
│   ├── detected_images/                Annotated image outputs
│   ├── detected_videos/                Annotated video outputs
│   └── evaluation_results/             Metrics (.mat) + PR-curve / AP plots (.png)
│
├── assistance/
│   ├── assistance_layer.m              Ranks detections by proximity/urgency
│   ├── generateAssistanceMessage.m     Short spoken hazard/status message
│   └── generateSceneMessage.m          Fuller "describe my surroundings" narration
│
├── speech/
│   └── text_to_speech.m                Cross-platform TTS (Windows/macOS/Linux)
│
├── utilities/                          Shared helper functions (see below)
│
├── step1_dataset_inspection.m          .. step10_realtime_webcam_detection.m
│
├── gTruth.mat, trainingData.mat, trainData.mat,
├── validationData.mat, testData.mat, anchorBoxes.mat   Generated automatically
├── input.jpg / input.mp4               Your sample media for Steps 8-9
└── README.md
```

## Workflow at a Glance

| Step | Script | What it does |
|---|---|---|
| 1 | `step1_dataset_inspection.m` | Scans the dataset, flags corrupt images, reports stats |
| 1b | `step1b_organize_dataset.m` | Renames/standardizes images into a clean `organized/` set |
| 2 | `step2_image_annotation.m` | Launches the Image Labeler app for manual bounding-box labeling |
| 3 | `step3_convert_labels_for_yolo.m` | Converts exported `gTruth.mat` into a YOLO training table |
| 4 | `step4_split_dataset.m` | Splits into train / validation / test (70/15/15 by default) |
| 5 | `step5_create_yolov4_detector.m` | Estimates anchor boxes, builds an untrained `yolov4ObjectDetector` |
| 6 | `step6_train_yolov4.m` | Trains with augmentation, checkpoints, and live training plots |
| 7 | `step7_evaluate_model.m` | Computes mAP/precision/recall/F1, generates publication-quality plots |
| 8 | `step8_detect_image.m` | Detects objects in `input.jpg`, speaks an assistance message |
| 9 | `step9_detect_video.m` | Detects objects across `input.mp4`, narrates periodically |
| 10 | `step10_realtime_webcam_detection.m` | Live webcam detection with real-time narration |

## Quick Start

```matlab
>> run_project
```

This opens an interactive menu. Or drive it directly:

```matlab
main_capstone('full')      % run every step 1 -> 10
main_capstone('prepare')   % steps 1, 1b, 3, 4  (data prep; run Step 2 manually in between)
main_capstone('train')     % steps 5, 6, 7      (build + train + evaluate)
main_capstone('demo')      % steps 8, 9         (one-click demo, needs a trained model)
main_capstone('webcam')    % step 10 only       (live demo, needs a trained model)
main_capstone(7)           % run a single numbered step
```

> **Note:** Step 2 (Image Labeler) is an interactive MATLAB app and cannot
> be fully scripted. `main_capstone('prepare')` stops before it by design —
> run `step2_image_annotation.m` yourself, export `gTruth.mat`, then
> continue with `step3` onward.

## First-Time Setup

1. **Add images.** Drop your raw photos into `dataset/everydayObjectDataset/`.
2. **Check toolboxes.** `main_capstone` automatically verifies Computer
   Vision Toolbox, Deep Learning Toolbox, and Image Processing Toolbox are
   installed (via `utilities/checkToolboxes.m`) and warns you if the
   **Computer Vision Toolbox Model for YOLO v4 Object Detection** support
   package (needed for `yolov4ObjectDetector`) is missing.
3. **Edit classes.** Update `cfg.classNames` in `config/project_config.m`
   to match the object categories you plan to label.
4. **Run the pipeline** as shown above.

## Required Toolboxes

- Computer Vision Toolbox (+ *Computer Vision Toolbox Model for YOLO v4
  Object Detection* support package)
- Deep Learning Toolbox
- Image Processing Toolbox
- A CUDA-capable GPU is **strongly recommended** for Step 6 (training);
  CPU training will work but is significantly slower.

## The Assistance Layer

`assistance_layer.m` converts raw detector output (`bboxes`, `scores`,
`labels`) into a ranked struct array with proximity (`very close` /
`close` / `nearby` / `far`, based on how much of the frame a box
occupies) and position (`left` / `center` / `right`). Two message
generators consume this:

- **`generateAssistanceMessage.m`** — short, real-time, leads with an
  explicit caution if something is very close and centered (a likely
  path hazard). Used in Steps 8-10.
- **`generateSceneMessage.m`** — a fuller descriptive summary ("I can
  see a chair and two people in view. 1 directly ahead, 1 to your
  left...") intended for on-demand "describe the scene" narration
  rather than continuous alerts.

`speech/text_to_speech.m` speaks these messages using the native TTS
engine for whatever OS MATLAB is running on (SAPI on Windows, `say` on
macOS, `espeak`/`spd-say` on Linux), and never throws — a speech failure
is logged as a warning so it can't crash the detection pipeline.

## Logging, Errors, and Progress

- Every step logs to `logs/capstone_YYYYMMDD.log` via
  `utilities/logMessage.m`, timestamped and leveled (INFO/WARN/ERROR).
- Every step is wrapped in `try/catch` with actionable error messages
  (e.g. missing files tell you exactly which prior step to re-run).
- Long-running loops (dataset inspection, organization, video/frame
  processing, evaluation) print periodic `Progress: X / Y (Z%)` updates.

## Evaluation Output

Step 7 saves, under `results/evaluation_results/`:
- `yolov4_evaluation_<timestamp>.mat` — full metrics struct (per-class
  AP, precision/recall curves, F1, confusion counts, mAP)
- A tiled **precision-recall curve** figure per class
- An **AP-by-class bar chart**

Both figures are exported as high-resolution PNGs suitable for a
capstone report or presentation.

## Customization

All tunable parameters live in **`config/project_config.m`**:
train/val/test split ratios, YOLOv4 base network (`tiny-yolov4-coco` by
default — swap to `csp-darknet53-coco` for higher accuracy at the cost
of speed), number of anchors, training hyperparameters (epochs, learning
rate, batch size), detection thresholds, and all assistance/speech
tuning (proximity threshold, message length, narration throttle).

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| `yolov4ObjectDetector` undefined | Missing YOLO v4 support package — install via Add-On Explorer |
| Step 3 error about missing images | `gTruth.mat` references absolute paths that moved — re-export from Image Labeler after finalizing file locations |
| Training crashes partway | Check `models/checkpoints/` for the latest `net_checkpoint__*.mat` and resume manually |
| No sound from `text_to_speech` | Confirm `cfg.speech.enabled = true` and that your OS has a supported TTS engine (see Assistance Layer section) |
| `webcam()` undefined | Install "MATLAB Support Package for USB Webcams" |

---

*Built as a MATLAB capstone project demonstrating an end-to-end deep
learning pipeline: data preparation, custom object detector training,
rigorous evaluation, and a practical assistive-technology application
layer.*
