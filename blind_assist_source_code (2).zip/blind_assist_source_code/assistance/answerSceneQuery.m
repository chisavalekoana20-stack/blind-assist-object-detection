function answer = answerSceneQuery(question, sceneInfo, cfg)
%ANSWERSCENEQUERY Answer a simple typed question about the current scene.
%   ANSWER = ANSWERSCENEQUERY(QUESTION, SCENEINFO, CFG)
%
%   QUESTION is a typed string/char, e.g.:
%       "where is the chair"
%       "is there a person"
%       "how many chairs are there"
%       "what do you see"
%
%   SCENEINFO is the struct array produced by assistance_layer.m for the
%   CURRENT frame/image (one entry per detected object, with fields
%   .label, .score, .position, .proximity, .areaFraction, .priority).
%
%   CFG is the project config struct (used to look up known class names
%   so the question can be matched against them).
%
%   This is deliberately simple keyword/pattern matching, not a general
%   NLP system -- it recognizes a fixed set of question shapes per known
%   class name. Unrecognized questions get a helpful fallback answer
%   rather than an error, so a live demo never crashes on an unexpected
%   question.
%
%   Supported question patterns (case-insensitive):
%     "where is the <class>" / "where are the <class>s"
%     "is there a <class>" / "is there any <class>" / "do you see a <class>"
%     "how many <class>s" / "how many <class> are there"
%     "what do you see" / "describe the scene" / "what is around me"
%
%   ANSWER is a plain char string, ready to print and/or pass to
%   text_to_speech.m.

    if nargin < 3
        error('answerSceneQuery:missingCfg', 'CFG is required to look up known class names.');
    end

    q = lower(strtrim(char(question)));

    if isempty(q)
        answer = "I didn't catch a question -- try asking where something is, or what you see.";
        answer = char(answer);
        return;
    end

    % ---- General "describe everything" queries ----
    generalPhrases = {'what do you see', 'describe the scene', 'what is around me', ...
                       'what''s around me', 'whats around me', 'describe my surroundings'};
    if any(cellfun(@(p) contains(q, p), generalPhrases))
        answer = generateSceneMessageFromInfo(sceneInfo);
        return;
    end

    % ---- Try to match a known class name inside the question ----
    matchedClass = '';
    for c = 1:numel(cfg.classNames)
        className = lower(cfg.classNames{c});
        % match both singular and a naive plural ("chair" or "chairs")
        if contains(q, className) || contains(q, [className 's'])
            matchedClass = cfg.classNames{c};
            break;
        end
    end

    if isempty(matchedClass)
        knownList = strjoin(cfg.classNames, ', ');
        answer = sprintf(['I''m not trained to recognize that yet. Right now I can only ' ...
                           'answer about: %s.'], knownList);
        return;
    end

    % ---- Robust comparison: normalize both sides to lowercase, trimmed
    % strings before comparing, so char-vs-string type differences (or
    % stray whitespace) can never silently break the match. ----
    if isempty(sceneInfo)
        sceneLabels = strings(0);
    else
        sceneLabels = lower(strtrim(string({sceneInfo.label})));
    end
    targetLabel = lower(strtrim(string(matchedClass)));
    matches = sceneInfo(sceneLabels == targetLabel);

    % ---- "where is/are" ----
    if contains(q, 'where')
        if isempty(matches)
            answer = sprintf('I don''t currently see any %s.', matchedClass);
        elseif numel(matches) == 1
            answer = sprintf('The %s is %s, %s.', matchedClass, matches(1).position, matches(1).proximity);
        else
            parts = strings(1, numel(matches));
            for k = 1:numel(matches)
                parts(k) = sprintf('one %s, %s', matches(k).position, matches(k).proximity);
            end
            answer = sprintf('There are %d %ss: %s.', numel(matches), matchedClass, strjoin(parts, '; '));
        end
        return;
    end

    % ---- "how many" ----
    if contains(q, 'how many')
        answer = sprintf('There %s %d %s%s in view.', ...
            plural_is_are(numel(matches)), numel(matches), matchedClass, plural_suffix(numel(matches)));
        return;
    end

    % ---- "is there" / "is there any" / "do you see" ----
    if contains(q, 'is there') || contains(q, 'do you see') || contains(q, 'any ')
        if isempty(matches)
            answer = sprintf('No, I don''t see a %s right now.', matchedClass);
        else
            closest = matches(1); % sceneInfo is already priority-sorted
            answer = sprintf('Yes, there %s %d %s%s -- the closest one is %s, %s.', ...
                plural_is_are(numel(matches)), numel(matches), matchedClass, ...
                plural_suffix(numel(matches)), closest.position, closest.proximity);
        end
        return;
    end

    % ---- Fallback: unrecognized phrasing but known class ----
    if isempty(matches)
        answer = sprintf('I don''t currently see any %s.', matchedClass);
    else
        answer = sprintf('I see %d %s%s in view.', numel(matches), matchedClass, plural_suffix(numel(matches)));
    end
end

function s = plural_suffix(n)
    if n == 1
        s = '';
    else
        s = 's';
    end
end

function s = plural_is_are(n)
    if n == 1
        s = 'is';
    else
        s = 'are';
    end
end

function msg = generateSceneMessageFromInfo(sceneInfo)
    if isempty(sceneInfo)
        msg = 'The scene appears clear. No recognizable objects were detected.';
        return;
    end
    allLabels = string({sceneInfo.label});
    uniqueLabels = unique(allLabels, 'stable');
    parts = strings(1, numel(uniqueLabels));
    for i = 1:numel(uniqueLabels)
        cnt = sum(allLabels == uniqueLabels(i));
        if cnt == 1
            parts(i) = sprintf('a %s', uniqueLabels(i));
        else
            parts(i) = sprintf('%d %ss', cnt, uniqueLabels(i));
        end
    end
    msg = char(sprintf('I can see %s in view.', strjoin(parts, ', ')));
end
