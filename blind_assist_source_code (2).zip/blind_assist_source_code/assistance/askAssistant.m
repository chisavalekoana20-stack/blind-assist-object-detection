function askAssistant(imagePath)
%ASKASSISTANT Interactive typed Q&A session about a detected scene.
%   ASKASSISTANT() runs YOLOv8 detection once on cfg.paths.sampleImage
%   (input.jpg), then repeatedly prompts you to type questions like:
%       where is the chair
%       is there a chair
%       how many chairs are there
%       what do you see
%   answering each via answerSceneQuery.m and speaking the answer aloud
%   via text_to_speech.m. Type "exit" or "quit" to stop.
%
%   ASKASSISTANT(IMAGEPATH) runs detection on a specific image instead of
%   the default sample image.
%
%   NOTE: this snapshots ONE detection result and answers questions
%   against that fixed snapshot -- it does not re-run detection live for
%   every question.

    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();

    if nargin < 1
        imagePath = cfg.paths.sampleImage;
    end
    if ~isfile(imagePath)
        error('askAssistant:missingImage', ...
            'Image not found at %s. Place an image there or pass a path to askAssistant().', imagePath);
    end

    ONNX_MODEL_PATH = fullfile(cfg.paths.modelsDir, 'best.onnx');
    if ~exist('net', 'var')
        fprintf('Importing YOLOv8 ONNX model from %s...\n', ONNX_MODEL_PATH);
        net = importNetworkFromONNX(ONNX_MODEL_PATH);
    end
    classNames = getYOLOv8ClassNames();

    fprintf('Running detection on: %s\n', imagePath);
    img = imread(imagePath);

    [bboxes, scores, labels] = detectYOLOv8(net, img, classNames, ...
        'Threshold', cfg.detect.confidenceThreshold, ...
        'SelectStrongest', true, ...
        'OverlapThreshold', cfg.detect.overlapThreshold);

    sceneInfo = assistance_layer(bboxes, scores, labels, size(img), cfg);
    fprintf('Detected %d object(s) in the scene.\n', numel(sceneInfo));

    annotated = visualizeDetections(img, bboxes, scores, labels, 'ShowMinimap', true);
    figure('Name', 'Scene Q&A', 'Color', 'w');
    imshow(annotated);
    title(sprintf('%d objects detected -- ask questions in the Command Window', numel(sceneInfo)));

    fprintf('\n--------------------------------------------------------------\n');
    fprintf('Ask a question about this scene (type "exit" to quit).\n');
    fprintf('Examples: "where is the chair", "is there a chair", "how many chairs", "what do you see"\n');
    fprintf('Known classes: %s\n', strjoin(cfg.classNames, ', '));
    fprintf('--------------------------------------------------------------\n\n');

    while true
        question = input('Ask a question: ', 's');
        if any(strcmpi(strtrim(question), {'exit', 'quit', 'q'}))
            fprintf('Ending Q&A session.\n');
            break;
        end
        try
            answer = answerSceneQuery(question, sceneInfo, cfg);
        catch qaErr
            answer = sprintf('Sorry, I had trouble with that question (%s).', qaErr.message);
        end
        fprintf('  %s\n\n', answer);
        if cfg.speech.enabled
            text_to_speech(answer, cfg);
        end
    end
end