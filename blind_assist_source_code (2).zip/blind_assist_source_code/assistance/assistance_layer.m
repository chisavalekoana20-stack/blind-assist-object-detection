function sceneInfo = assistance_layer(bboxes, scores, labels, imageSize, cfg)
%ASSISTANCE_LAYER Turn raw detections into structured, prioritized scene
%information for a visually-impaired assistance use case.
%
%   SCENEINFO = ASSISTANCE_LAYER(BBOXES, SCORES, LABELS, IMAGESIZE, CFG)
%   takes the standard detector() outputs plus the [H W C] size of the
%   source frame and returns a struct array SCENEINFO, one entry per
%   detected object, sorted by priority (closest / most confident /
%   most central first), with fields:
%
%     .label        class name (string)
%     .score        detection confidence [0,1]
%     .bbox         [x y w h]
%     .areaFraction fraction of the frame this box occupies (0-1)
%     .position     'left' | 'center' | 'right'
%     .proximity    'very close' | 'close' | 'nearby' | 'far'
%     .priority     numeric priority score (higher = more urgent)
%
%   This struct array is the single source of truth consumed by
%   generateAssistanceMessage.m and generateSceneMessage.m, keeping the
%   "what is out there and how urgent is it" logic in one place.

    numObjects = numel(labels);
    sceneInfo = repmat(struct('label', '', 'score', 0, 'bbox', [0 0 0 0], ...
        'areaFraction', 0, 'position', '', 'proximity', '', 'priority', 0), numObjects, 1);

    if numObjects == 0
        sceneInfo = sceneInfo([]);
        return;
    end

    frameArea = imageSize(1) * imageSize(2);
    frameWidth = imageSize(2);

    for k = 1:numObjects
        box = bboxes(k, :);
        areaFraction = (box(3) * box(4)) / frameArea;

        centerX = box(1) + box(3) / 2;
        third = frameWidth / 3;
        if centerX < third
            position = 'left';
        elseif centerX < 2 * third
            position = 'center';
        else
            position = 'right';
        end

        if areaFraction >= cfg.assistance.proximityWarningArea
            proximity = 'very close';
        elseif areaFraction >= cfg.assistance.proximityWarningArea * 0.5
            proximity = 'close';
        elseif areaFraction >= cfg.assistance.proximityWarningArea * 0.15
            proximity = 'nearby';
        else
            proximity = 'far';
        end

        % Priority favors large/close objects in the center of frame
        % (path-blocking hazards) and high detection confidence.
        centerBias = 1 - abs(centerX - frameWidth/2) / (frameWidth/2); % 1 at center, 0 at edges
        priority = (areaFraction * 3) + (double(scores(k)) * 1.5) + (centerBias * 1.0);

        sceneInfo(k).label = string(labels(k));
        sceneInfo(k).score = double(scores(k));
        sceneInfo(k).bbox = box;
        sceneInfo(k).areaFraction = areaFraction;
        sceneInfo(k).position = position;
        sceneInfo(k).proximity = proximity;
        sceneInfo(k).priority = priority;
    end

    [~, order] = sort([sceneInfo.priority], 'descend');
    sceneInfo = sceneInfo(order);
end
