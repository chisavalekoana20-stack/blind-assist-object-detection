function message = generateAssistanceMessage(bboxes, scores, labels, imageSize, cfg)
%GENERATEASSISTANCEMESSAGE Produce a short, prioritized natural-language
%message describing the most important detected objects, suitable for
%immediate text-to-speech playback (e.g. "Chair very close, center.
%Door nearby, left.").
%
%   MESSAGE = GENERATEASSISTANCEMESSAGE(BBOXES, SCORES, LABELS, IMAGESIZE, CFG)
%
%   Internally calls assistance_layer() to rank objects by priority, then
%   verbalizes at most CFG.assistance.maxObjectsPerMessage of them,
%   leading with the single highest-priority hazard as a distinct
%   sentence when it is "very close", so the most urgent information is
%   never buried in a list.

    sceneInfo = assistance_layer(bboxes, scores, labels, imageSize, cfg);

    if isempty(sceneInfo)
        message = 'No objects detected.';
        return;
    end

    numToSpeak = min(cfg.assistance.maxObjectsPerMessage, numel(sceneInfo));
    parts = strings(1, numToSpeak);

    for k = 1:numToSpeak
        obj = sceneInfo(k);
        parts(k) = sprintf('%s %s, %s', capitalizeFirst(obj.label), obj.proximity, obj.position);
    end

    % Lead with an explicit hazard warning if the top object is very close.
    if strcmp(sceneInfo(1).proximity, 'very close')
        warningPrefix = sprintf('Caution: %s %s ahead. ', sceneInfo(1).label, sceneInfo(1).position);
        remaining = parts;
        if numToSpeak > 1
            remaining = parts(2:end);
        else
            remaining = strings(1,0);
        end
        if isempty(remaining)
            message = strtrim(warningPrefix);
        else
            message = strtrim([warningPrefix, char(strjoin(remaining, '. ')), '.']);
        end
    else
        message = char(strjoin(parts, '. ') + ".");
    end
end

function s = capitalizeFirst(str)
    str = char(str);
    if isempty(str)
        s = str;
    else
        s = [upper(str(1)), str(2:end)];
    end
end