function message = generateRoomMessage(labels, cfg)
%GENERATEROOMMESSAGE Infer a coarse room type from detected object
%classes and produce a short spoken announcement (e.g. "You are in
%the kitchen."). Returns '' if no defining objects are seen, so the
%caller can decide to stay silent rather than guess.
%
%   MESSAGE = GENERATEROOMMESSAGE(LABELS, CFG)
%   LABELS is the filtered label list from the current detection frame.

    detectedLabels = string(labels);

    kitchenObjects    = ["oven", "refrigerator", "microwave", "sink"];
    bathroomObjects   = ["toilet"];
    bedroomObjects    = ["bed"];
    livingRoomObjects = ["couch"];

    if any(ismember(detectedLabels, kitchenObjects))
        message = 'You are in the kitchen.';
    elseif any(ismember(detectedLabels, bathroomObjects))
        message = 'You are in the bathroom.';
    elseif any(ismember(detectedLabels, bedroomObjects))
        message = 'You are in the bedroom.';
    elseif any(ismember(detectedLabels, livingRoomObjects))
        message = 'You are in the living room.';
    else
        message = '';
    end
end