function message = generateSceneMessage(bboxes, scores, labels, imageSize, cfg)
%GENERATESCENEMESSAGE Produce a fuller, descriptive narration of the
%entire scene (as opposed to generateAssistanceMessage's short hazard
%alert). Groups objects by class, reports counts, and gives an overall
%layout description -- suited for an on-demand "describe my
%surroundings" request rather than continuous real-time narration.
%
%   MESSAGE = GENERATESCENEMESSAGE(BBOXES, SCORES, LABELS, IMAGESIZE, CFG)

    sceneInfo = assistance_layer(bboxes, scores, labels, imageSize, cfg);

    if isempty(sceneInfo)
        message = 'The scene appears clear. No recognizable objects were detected.';
        return;
    end

    allLabels = string({sceneInfo.label});
    uniqueLabels = unique(allLabels, 'stable');

    classPhrases = strings(1, numel(uniqueLabels));
    for i = 1:numel(uniqueLabels)
        cnt = sum(allLabels == uniqueLabels(i));
        if cnt == 1
            classPhrases(i) = sprintf('a %s', uniqueLabels(i));
        else
            classPhrases(i) = sprintf('%d %ss', cnt, uniqueLabels(i));
        end
    end

    if numel(classPhrases) == 1
        objectSummary = classPhrases(1);
    elseif numel(classPhrases) == 2
        objectSummary = classPhrases(1) + " and " + classPhrases(2);
    else
        objectSummary = strjoin(classPhrases(1:end-1), ', ') + ", and " + classPhrases(end);
    end

    intro = sprintf('I can see %s in view.', objectSummary);

    % Describe layout by position bucket for spatial awareness.
    positions = string({sceneInfo.position});
    leftCount = sum(positions == "left");
    centerCount = sum(positions == "center");
    rightCount = sum(positions == "right");

    layoutParts = {};
    if centerCount > 0
        layoutParts{end+1} = sprintf('%d directly ahead', centerCount);
    end
    if leftCount > 0
        layoutParts{end+1} = sprintf('%d to your left', leftCount);
    end
    if rightCount > 0
        layoutParts{end+1} = sprintf('%d to your right', rightCount);
    end
    layoutSentence = '';
    if ~isempty(layoutParts)
        layoutSentence = [' ', strjoin(layoutParts, ', '), '.'];
    end

    % Call out the single most urgent item, if any, as a closing note.
    closing = '';
    nearest = sceneInfo(1);
    if any(strcmp({sceneInfo.proximity}, 'very close'))
        closing = sprintf(' The nearest object, a %s, is very close %s of you.', ...
            nearest.label, nearest.position);
    end

    message = [char(intro), layoutSentence, closing];
end
