function phoneSearchAssistant()
%PHONESEARCHASSISTANT MATLAB search, beeps and speech with live phone detections.
% Start phone_worker.py in PowerShell first; press q in the figure to stop.
    root = fileparts(mfilename('fullpath'));
    addpath(root, fullfile(root,'config'), fullfile(root,'utilities'), ...
        fullfile(root,'assistance'), fullfile(root,'speech'));
    cfg = project_config();
    classes = {'person','bicycle','car','motorcycle','bus','truck', ...
        'traffic light','stop sign','bench','dog','cat','chair','couch', ...
        'dining table','bed','toilet','cell phone','bottle','refrigerator'};
    query = lower(strtrim(input('What are you looking for? ', 's')));
    target = '';
    for k = 1:numel(classes)
        if contains(query, classes{k})
            target = classes{k}; break;
        end
    end
    if isempty(target)
        fprintf('Choose one of: %s\n', strjoin(classes, ', ')); return;
    end
    base = 'http://127.0.0.1:8765';
    opts = weboptions('Timeout', 5);
    try
        webread([base '/detections'], opts);
    catch
        error('Start phone_worker.py in PowerShell before running this function.');
    end
    text_to_speech(['Searching for ' target], cfg);
    stop = false;
    fig = figure('Name','Phone Search Assistant','KeyPressFcn',@onKey);
    ax = axes('Parent',fig);
    cleanup = onCleanup(@()deleteIfOpen(fig)); %#ok<NASGU>
    lastSeq = -1;
    lastSpoken = '';
    foundAnnounced = false;
    lastBeep = tic;
    lastSpeech = tic;
    while isgraphics(fig) && ~stop
        try
            data = webread([base '/detections'], opts);
            if ~isempty(data.error)
                fprintf('Camera: %s\n', data.error); pause(0.5); continue;
            end
            if double(data.seq) == lastSeq
                pause(0.1); drawnow; continue;
            end
            lastSeq = double(data.seq);
            imageFile = [tempname '.jpg'];
            websave(imageFile, [base '/frame.jpg'], opts);
            frame = imread(imageFile);
            delete(imageFile);
            detections = data.detections;
            boxes = zeros(0,4); scores = zeros(0,1); names = strings(0,1);
            for j = 1:numel(detections)
                boxes(end+1,:) = double(detections(j).bbox); %#ok<AGROW>
                scores(end+1,1) = double(detections(j).score); %#ok<AGROW>
                names(end+1,1) = string(detections(j).label); %#ok<AGROW>
            end
            visible = names == target | names == "person";
            annotated = visualizeDetections(frame, boxes(visible,:), scores(visible), ...
                categorical(names(visible),classes), 'ShowMinimap',false);
            imshow(annotated,'Parent',ax);
            title(ax, sprintf('Searching for %s | q to quit',target));
            drawnow limitrate;
            matches = names == target;
            if ~any(matches)
                lastSpoken = ''; foundAnnounced = false; continue;
            end
            scene = assistance_layer(boxes(matches,:), scores(matches), ...
                categorical(names(matches),classes), size(frame), cfg);
            nearest = scene(1);
            switch nearest.proximity
                case 'very close', interval = 0.15;
                case 'close', interval = 0.4;
                case 'nearby', interval = 0.9;
                otherwise, interval = Inf;
            end
            if toc(lastBeep) >= interval
                playProximityBeep(nearest.proximity); lastBeep = tic;
            end
            if strcmp(nearest.proximity,'very close') && ~foundAnnounced
                message = sprintf('Found it. %s is %s, in front of you.',target,nearest.position);
                fprintf('%s\n',message); text_to_speech(message,cfg);
                lastSpeech = tic; foundAnnounced = true;
            elseif ~strcmp(nearest.proximity,lastSpoken) && toc(lastSpeech) > 4
                message = sprintf('%s is %s, %s.',target,nearest.proximity,nearest.position);
                fprintf('%s\n',message); text_to_speech(message,cfg);
                lastSpeech = tic; foundAnnounced = false;
            end
            lastSpoken = nearest.proximity;
        catch err
            if ~isgraphics(fig), break; end
            fprintf('Retrying camera frame: %s\n',err.message);
            pause(0.5);
        end
    end
    function onKey(~,evt)
        if strcmpi(evt.Key,'q'), stop = true; end
    end
end

function deleteIfOpen(fig)
    if isgraphics(fig), delete(fig); end
end
