function searchAssistant()
%SEARCHASSISTANT Live webcam search mode: ask for an object by name, then
%continuously scan the webcam feed for it, beeping faster as it gets
%closer and slower as it gets farther (like a parking sensor), and
%announcing when it's clearly found. Draws boxes on BOTH the target
%object and any person in view, so you can see yourself and the object
%in the same frame.
%
%   SEARCHASSISTANT() prompts you to type what you're looking for
%   (e.g. "where is my phone"), matches it against known class names,
%   then opens your laptop webcam and searches live until the object is
%   found (announced) or you stop the search ('q' in the video window,
%   or Ctrl+C).

    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();

    ONNX_MODEL_PATH = fullfile(cfg.paths.modelsDir, 'best.onnx');

    if ~exist('net', 'var')
        fprintf('Importing YOLOv8 ONNX model from %s...\n', ONNX_MODEL_PATH);
        net = importNetworkFromONNX(ONNX_MODEL_PATH);
    end
    classNames = getYOLOv8ClassNames();

    % ---- Step 1: ask what to search for ----
    question = input('What are you looking for? (e.g. "where is my phone"): ', 's');
    targetClass = matchTargetClass(question, cfg.classNames);

    if isempty(targetClass)
        fprintf('I don''t recognize that object. Known classes: %s\n', strjoin(cfg.classNames, ', '));
        return;
    end

    fprintf('Searching for: %s\n', targetClass);
    fprintf('Move the camera around. Beeps speed up as you get closer, slow down as you move away.\n');
    fprintf('Press "q" in the video window, or Ctrl+C here, to stop.\n\n');
    if cfg.speech.enabled
        text_to_speech(sprintf('Searching for %s.', targetClass), cfg);
    end

    % ---- Step 2: open the laptop webcam ----
    camList = webcamlist;
    if isempty(camList)
        error('searchAssistant:noWebcam', 'No webcam detected on this laptop.');
    end
    cam = webcam(1);  % laptop's built-in camera is normally the first/default device

    fig = figure('Name', 'Search Assistant', 'Color', 'w', 'KeyPressFcn', @keyPressCallback);
    ax = axes('Parent', fig);
    stopFlag = false;

    function keyPressCallback(~, event)
        if strcmpi(event.Key, 'q')
            stopFlag = true;
        end
    end

    % ---- Beep rate mapping: proximity -> minimum seconds between beeps.
    % Smaller interval = beeps fire more often = feels "faster". ----
    beepIntervals = containers.Map( ...
        {'very close', 'close', 'nearby', 'far'}, ...
        {0.15,         0.4,     0.9,       Inf});   % Inf = no beep at all

    % ---- State tracking ----
    lastSpokenProximity = '';
    foundAnnounced = false;
    lastBeepTic = 0;

    % ---- Step 3: live search loop ----
    while ishandle(fig) && ~stopFlag

        frame = snapshot(cam);

        [bboxes, scores, labels] = detectYOLOv8(net, frame, classNames, ...
            'Threshold', cfg.detect.confidenceThreshold, ...
            'SelectStrongest', true, ...
            'OverlapThreshold', cfg.detect.overlapThreshold);

        % Keep BOTH the target object and any person, so you can see
        % yourself and the object together in the annotated frame.
        allLabels = string(labels);
        showIdx = strcmpi(allLabels, targetClass) | strcmpi(allLabels, "person");
        showBoxes  = bboxes(showIdx, :);
        showScores = scores(showIdx);
        showLabels = labels(showIdx);

        annotated = visualizeDetections(frame, showBoxes, showScores, showLabels, 'ShowMinimap', false);
        imshow(annotated, 'Parent', ax);
        title(ax, sprintf('Searching for: %s', targetClass));
        drawnow;

        % Proximity/beep logic looks ONLY at the target object, not the person
        targetIdx = strcmpi(allLabels, targetClass);
        tBoxes  = bboxes(targetIdx, :);
        tScores = scores(targetIdx);
        tLabels = labels(targetIdx);

        if isempty(tLabels)
            % Target not currently visible -- stay quiet, keep scanning
            lastSpokenProximity = '';
            foundAnnounced = false;
        else
            sceneInfo = assistance_layer(tBoxes, tScores, tLabels, size(frame), cfg);
            nearest = sceneInfo(1);  % priority-sorted; closest/most confident first

            % --- Rate-based beep: fires more often the closer you are ---
            requiredInterval = beepIntervals(nearest.proximity);
            if isfinite(requiredInterval) && elapsedSince(lastBeepTic) > requiredInterval
                playProximityBeep(nearest.proximity);
                lastBeepTic = tic;
            end

            % Announce once when it becomes "very close" (i.e. found)
            if strcmp(nearest.proximity, 'very close') && ~foundAnnounced
                msg = sprintf('Found it. The %s is %s, right in front of you.', ...
                    targetClass, nearest.position);
                fprintf('%s\n', msg);
                if cfg.speech.enabled
                    text_to_speech(msg, cfg);
                end
                foundAnnounced = true;

            elseif ~strcmp(nearest.proximity, lastSpokenProximity) && ~strcmp(nearest.proximity, 'very close')
                fprintf('%s is %s, %s.\n', targetClass, nearest.proximity, nearest.position);
                lastSpokenProximity = nearest.proximity;
                foundAnnounced = false;  % reset in case it moves away again
            end
        end
    end

    clear cam;
    if ishandle(fig)
        close(fig);
    end
    fprintf('Search ended.\n');
end

function targetClass = matchTargetClass(question, classNames)
%MATCHTARGETCLASS Find a known class name mentioned in a typed question.
    q = lower(strtrim(question));
    targetClass = '';
    for c = 1:numel(classNames)
        cn = lower(classNames{c});
        if contains(q, cn) || contains(q, [cn 's'])
            targetClass = classNames{c};
            return;
        end
    end
end

function elapsed = elapsedSince(t)
%ELAPSEDSINCE Returns elapsed time since T (a tic value), or Inf if T==0
%(i.e. no beep has played yet, so the first one is never delayed).
    if isequal(t, 0)
        elapsed = Inf;
    else
        elapsed = toc(t);
    end
end
