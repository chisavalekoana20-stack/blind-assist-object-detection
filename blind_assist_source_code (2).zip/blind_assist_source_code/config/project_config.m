function cfg = project_config()
%PROJECT_CONFIG Central configuration for the capstone pipeline.
%   CFG = PROJECT_CONFIG() returns a struct with every path, class name,
%   hyperparameter, and toggle used across the ten workflow steps. Edit
%   this file to change project-wide behavior instead of hunting through
%   individual step scripts.

    % ---------------------------------------------------------------
    % Project root (auto-detected as the parent of this config/ folder)
    % ---------------------------------------------------------------
    thisFile = mfilename('fullpath');
    configDir = fileparts(thisFile);
    cfg.projectRoot = fileparts(configDir);

    % ---------------------------------------------------------------
    % Paths
    % ---------------------------------------------------------------
    cfg.paths.root                  = cfg.projectRoot;
    cfg.paths.datasetDir            = fullfile(cfg.projectRoot, 'dataset', 'everydayObjectDataset');
    cfg.paths.modelsDir             = fullfile(cfg.projectRoot, 'models');
    cfg.paths.resultsDir            = fullfile(cfg.projectRoot, 'results');
    cfg.paths.detectedImagesDir     = fullfile(cfg.projectRoot, 'results', 'detected_images');
    cfg.paths.detectedVideosDir     = fullfile(cfg.projectRoot, 'results', 'detected_videos');
    cfg.paths.evaluationResultsDir  = fullfile(cfg.projectRoot, 'results', 'evaluation_results');
    cfg.paths.logsDir               = fullfile(cfg.projectRoot, 'logs');
    cfg.paths.testImagesDir         = fullfile(cfg.projectRoot, 'test_images');
    cfg.paths.gTruthFile            = fullfile(cfg.projectRoot, 'gTruth.mat');
    cfg.paths.trainingDataFile      = fullfile(cfg.projectRoot, 'trainingData.mat');
    cfg.paths.trainDataFile         = fullfile(cfg.projectRoot, 'trainData.mat');
    cfg.paths.validationDataFile    = fullfile(cfg.projectRoot, 'validationData.mat');
    cfg.paths.testDataFile          = fullfile(cfg.projectRoot, 'testData.mat');
    cfg.paths.anchorBoxesFile       = fullfile(cfg.projectRoot, 'anchorBoxes.mat');
    cfg.paths.trainedModelFile      = fullfile(cfg.projectRoot, 'models', 'trainedYOLOv4.mat');

    cfg.paths.sampleImage           = fullfile(cfg.projectRoot, 'input.jpg');
    cfg.paths.sampleVideo            = fullfile(cfg.projectRoot, 'input.mp4');

    % ---------------------------------------------------------------
    % Dataset / class definitions
    % ---------------------------------------------------------------
    % Everyday objects relevant to an assistive detection use-case.
    % Edit this list to match whatever you label in the Image Labeler.
    cfg.classNames = {
        'person', 'bicycle', 'car', 'motorcycle', 'bus', 'truck', ...
        'traffic light', 'stop sign', 'fire hydrant', ...
    'bench', 'backpack', 'handbag', 'suitcase', ...
    'dog', 'cat', ...
    'chair', 'couch', 'dining table', 'bed', 'toilet', ...
    'tv', 'laptop', 'cell phone', ...
    'cup', 'bottle', 'bowl', 'fork', 'knife', 'spoon', ...
    'refrigerator', 'microwave', 'oven', 'toaster', 'sink', 'clock', 'book'
    };

    cfg.imageFileExtensions = {'.jpg', '.jpeg', '.png', '.bmp'};

    % ---------------------------------------------------------------
    % Dataset split ratios (must sum to 1.0)
    % ---------------------------------------------------------------
    cfg.split.trainRatio = 0.70;
    cfg.split.valRatio   = 0.15;
    cfg.split.testRatio  = 0.15;
    cfg.split.randomSeed = 42;

    % ---------------------------------------------------------------
    % YOLOv4 model / training hyperparameters
    % ---------------------------------------------------------------
    cfg.model.baseNetwork      = 'tiny-yolov4-coco'; % or 'csp-darknet53-coco'
    cfg.model.inputSize        = [416 416 3];

    % IMPORTANT: number of detection heads/anchors depends on the base
    % network architecture -- these must match or training/inference
    % will be silently wrong (anchors misassigned to output heads).
    %   tiny-yolov4-coco    -> 2 detection heads (6 anchors total)
    %   csp-darknet53-coco  -> 3 detection heads (9 anchors total)
    if strcmpi(cfg.model.baseNetwork, 'tiny-yolov4-coco')
        cfg.model.numHeads   = 2;
    else
        cfg.model.numHeads   = 3;
    end
    cfg.model.numAnchors       = cfg.model.numHeads * 3; % 3 anchors per head

    cfg.train.miniBatchSize     = 8;
    cfg.train.maxEpochs         = 10;
    cfg.train.learningRate      = 1e-4;
    cfg.train.learnRateSchedule = 'piecewise';
    cfg.train.learnRateDropFactor = 0.1;
    cfg.train.learnRateDropPeriod = 30;
    cfg.train.l2Regularization   = 5e-4;
    cfg.train.momentum           = 0.9;
    cfg.train.shuffle            = 'every-epoch';
    cfg.train.verboseFrequency   = 25;
    cfg.train.useAugmentation    = true;
    cfg.train.executionEnvironment ='auto';
    cfg.train.checkpointPath     = fullfile(cfg.paths.modelsDir, 'checkpoints');

    % ---------------------------------------------------------------
    % Detection / evaluation thresholds
    % ---------------------------------------------------------------
    cfg.detect.confidenceThreshold = 0.6;
    cfg.detect.overlapThreshold    = 0.45; % NMS IoU threshold
    cfg.eval.iouThreshold           = 0.50;

    % ---------------------------------------------------------------
    % Assistance / speech settings
    % ---------------------------------------------------------------
    cfg.assistance.enabled              = true;
    cfg.assistance.proximityWarningArea = 0.20; % fraction of frame area => "close"
    cfg.assistance.maxObjectsPerMessage = 3;
    cfg.assistance.repeatSuppressSeconds = 4;   % avoid repeating same message too often

    cfg.speech.enabled       = true;
    cfg.speech.rate          = 175;  % words per minute (used by supported backends)
    cfg.speech.volume        = 1.0;
    cfg.speech.voice         = 'default';
    cfg.speech.saveAudioFiles = false;
    cfg.speech.audioOutDir   = fullfile(cfg.paths.resultsDir, 'speech_audio');

    % ---------------------------------------------------------------
    % Real-time webcam settings
    % ---------------------------------------------------------------
    cfg.webcam.resolution      = '640x480';
    cfg.webcam.maxDurationSecs = 120;
    cfg.webcam.displayFPSInfo  = true;

    % ---------------------------------------------------------------
    % Logging
    % ---------------------------------------------------------------
    cfg.logging.enabled  = true;
    cfg.logging.logFile  = fullfile(cfg.paths.logsDir, sprintf('capstone_%s.log', datestr(now, 'yyyymmdd')));
    cfg.logging.echoToConsole = true;
end