function main_capstone(mode)
%MAIN_CAPSTONE Entry point for the full object-detection assistance
%capstone pipeline.
%
%   MAIN_CAPSTONE() with no arguments shows an interactive menu.
%   MAIN_CAPSTONE('image')   detect objects + room in a single photo (YOLOv8, with speech)
%   MAIN_CAPSTONE('ask')     ask typed questions about a photo (e.g. "where is the chair?")
%   MAIN_CAPSTONE('video')   walk-through demo: detect objects + room changes
%                             across a video file (YOLOv8, with speech)
%   MAIN_CAPSTONE('webcam')  live real-time detection + room (YOLOv8, with speech)
%   MAIN_CAPSTONE('search')  live webcam search: ask "where is my phone?" etc.
%   MAIN_CAPSTONE('phone')   live phone camera search with best.pt
%   MAIN_CAPSTONE('dev')     developer tools submenu (full/prepare/train, steps 1-7)
%   MAIN_CAPSTONE(N)         runs a single numbered step, e.g. main_capstone(7).
%
%   Every step is wrapped in try/catch with logging, so a failure in one
%   step is reported clearly without leaving the workspace in a
%   confusing state.

    close all force;
    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();

    displayProjectBanner('Main Capstone Controller');
    createDirectories(cfg);

    fprintf('Checking required toolboxes...\n');
    checkToolboxes(true);
    fprintf('\n');

    assignin('base', 'cfg', cfg);

    % Developer-only steps (data prep / training pipeline)
    devSteps = struct( ...
        's1',  {'step1_dataset_inspection.m'}, ...
        's1b', {'step1b_organize_dataset.m'}, ...
        's2',  {'step2_image_annotation.m'}, ...
        's3',  {'step3_convert_labels_for_yolo.m'}, ...
        's4',  {'step4_split_dataset.m'}, ...
        's5',  {'step5_create_yolov4_detector.m'}, ...
        's6',  {'step6_train_yolov4.m'}, ...
        's7',  {'step7_evaluate_model.m'});

    % End-user assistive features (YOLOv8/ONNX pipeline, with room + speech)
    userSteps = struct( ...
        'image',  {'step8_detect_image_YOLOv8.m'}, ...
        'folder', {'step8b_detect_image_folder_YOLOv8.m'}, ...
        'video',  {'step9_detect_video_YOLOv8.m'}, ...
        'webcam', {'step10_realtime_webcam_detection_YOLOv8.m'});

    % If a specific mode/step was passed in directly, run just that once and stop
    % (no looping) -- looping only applies to the interactive menu below.
    if nargin > 0
        runOneMode(mode, cfg, devSteps, userSteps);
        return;
    end

    % --- Interactive menu loop: keep returning here until the user exits ---
    while true
        mode = interactiveMenu();

        if strcmp(mode, 'exit')
            fprintf('Goodbye.\n');
            break;
        end

        if strcmp(mode, 'menu')
            continue;   % typed 0 -- just redisplay the menu, do nothing else
        end

        try
            runOneMode(mode, cfg, devSteps, userSteps);
        catch ME
            fprintf(2, '\n*** "%s" failed: %s ***\n', mode, ME.message);
        end

        fprintf('\n');
        displayProjectBanner('Task Complete -- Returning to Menu');
        fprintf('\n');
    end
end

function runOneMode(mode, cfg, devSteps, userSteps)
    if isnumeric(mode)
        fieldOrder = fieldnames(devSteps);
        if mode < 1 || mode > numel(fieldOrder)
            error('main_capstone:badStepNumber', 'Step number must be between 1 and %d.', numel(fieldOrder));
        end
        runSteps(cfg, {devSteps.(fieldOrder{mode})});
        return;
    end

    switch lower(string(mode))
        case "image"
            runSteps(cfg, {userSteps.image});
        case "folder"
            runSteps(cfg, {userSteps.folder});
        case "ask"
            askAssistant();
        case "video"
            runSteps(cfg, {userSteps.video});
        case "webcam"
            runSteps(cfg, {userSteps.webcam});
        case "search"
            searchAssistant();
        case "phone"
            phoneSearchAssistant();
        case "fulldemo"
            fullDemo();
        case "dev"
            devMode = devMenu();
            switch devMode
                case "full"
                    runSteps(cfg, struct2cell(devSteps));
                case "prepare"
                    runSteps(cfg, {devSteps.s1, devSteps.s1b, devSteps.s3, devSteps.s4});
                case "train"
                    runSteps(cfg, {devSteps.s5, devSteps.s6, devSteps.s7});
            end
        otherwise
            error('main_capstone:unknownMode', 'Unknown mode "%s".', mode);
    end
end

function mode = interactiveMenu()
    fprintf('=== Blind-Assistance Detection System ===\n');
    fprintf('  0. Refresh / return to this menu\n');
    fprintf('  1. Detect objects in a photo\n');
    fprintf('  2. Detect objects in a folder of photos (step through with "next")\n');
    fprintf('  3. Ask questions about a photo (e.g. "where is the chair?")\n');
    fprintf('  4. Walk-through demo (video file)\n');
    fprintf('  5. Live camera detection (webcam)\n');
    fprintf('  6. Search for an object (ask "where is my phone?")\n');
    fprintf('  7. Developer tools (train / prepare / full pipeline)\n');
    fprintf('  8. Exit\n');
    fprintf('  9. Full guided demo (recording mode -- runs scenes 4, 6, 3 in sequence)\n');
    fprintf(' 10. Live phone camera search (best.pt, beeps and speech)\n');
    choice = input('Enter choice [0-10]: ', 's');
    modes = {'image', 'folder', 'ask', 'video', 'webcam', 'search', 'dev'};

    idx = str2double(choice);
    if idx == 0
        mode = 'menu';   % no-op: just loops back and shows the menu again
    elseif idx == 8
        mode = 'exit';
    elseif idx == 9
        mode = 'fulldemo';
    elseif idx == 10
        mode = 'phone';
    elseif isnan(idx) || idx < 1 || idx > numel(modes)
        fprintf('Invalid choice, defaulting to "image".\n');
        mode = 'image';
    else
        mode = modes{idx};
    end
end

function mode = devMenu()
    fprintf('\n--- Developer Tools ---\n');
    fprintf('  1. full     - Run the entire pipeline (steps 1-7)\n');
    fprintf('  2. prepare  - Data prep only (inspect, organize, convert, split)\n');
    fprintf('  3. train    - Build + train + evaluate the detector\n');
    choice = input('Enter choice [1-3]: ', 's');
    modes = {'full', 'prepare', 'train'};
    idx = str2double(choice);
    if isnan(idx) || idx < 1 || idx > numel(modes)
        fprintf('Invalid choice, defaulting to "full".\n');
        mode = 'full';
    else
        mode = modes{idx};
    end
end

function runSteps(cfg, stepFiles)
    for k = 1:numel(stepFiles)
        stepName = stepFiles{k};
        fprintf('\n>>> Running %s ...\n', stepName);
        try
            run(stepName);
            assignin('base', 'cfg', cfg); % keep cfg/detector consistent across steps
        catch ME
            logMessage(cfg, 'ERROR', 'Pipeline halted at %s: %s', stepName, ME.message);
            fprintf(2, '\n*** Step "%s" failed: %s ***\n', stepName, ME.message);
            fprintf(2, 'See the log file for details: %s\n', cfg.logging.logFile);
            rethrow(ME);
        end
    end
end
