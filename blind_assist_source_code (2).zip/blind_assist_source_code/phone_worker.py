"""Local camera/inference service for phoneSearchAssistant.m."""
import argparse
import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import cv2
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="best.pt")
    parser.add_argument("--source", required=True)
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--conf", type=float, default=0.35)
    args = parser.parse_args()

    model = YOLO(args.model)
    expected = ["person", "bicycle", "car", "motorcycle", "bus", "truck",
                "traffic light", "stop sign", "bench", "dog", "cat", "chair",
                "couch", "dining table", "bed", "toilet", "cell phone", "bottle",
                "refrigerator"]
    actual = [model.names[i] for i in sorted(model.names)]
    if actual != expected:
        raise RuntimeError(f"Wrong model classes: {actual}")

    lock = threading.Lock()
    latest = {"seq": 0, "detections": [], "error": "Waiting for camera"}
    frame_jpg = b""

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            with lock:
                data = json.dumps(latest).encode("utf-8") if self.path == "/detections" else frame_jpg
            if self.path not in ("/detections", "/frame.jpg"):
                self.send_error(404)
                return
            if self.path == "/frame.jpg" and not data:
                self.send_error(503)
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/json" if self.path == "/detections" else "image/jpeg")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *unused):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"MATLAB bridge ready at http://127.0.0.1:{args.port}", flush=True)

    while True:
        cap = cv2.VideoCapture(args.source)
        if not cap.isOpened():
            with lock:
                latest["error"] = "Cannot open phone stream; retrying"
            time.sleep(2)
            continue
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            frame = cv2.resize(frame, (640, 480))
            try:
                result = model.predict(frame, imgsz=640, conf=args.conf, verbose=False)[0]
                detections = []
                for box in result.boxes:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    detections.append({"label": model.names[int(box.cls[0])],
                                       "score": float(box.conf[0]),
                                       "bbox": [x1, y1, x2 - x1, y2 - y1]})
                ok_jpg, jpg = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 75])
                if ok_jpg:
                    with lock:
                        frame_jpg = jpg.tobytes()
                        latest = {"seq": latest["seq"] + 1, "detections": detections, "error": ""}
            except Exception as exc:
                with lock:
                    latest["error"] = str(exc)
                time.sleep(0.5)
        cap.release()
        time.sleep(1)


if __name__ == "__main__":
    main()
