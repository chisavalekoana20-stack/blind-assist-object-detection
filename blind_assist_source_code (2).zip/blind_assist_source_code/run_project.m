%% RUN_PROJECT
% Optional one-line launcher. From the project root in MATLAB, just run:
%
%   >> run_project
%
% This adds all necessary folders to the path and opens the interactive
% main_capstone menu. Equivalent to calling main_capstone() directly,
% provided here mainly for discoverability / a friendlier entry point
% for graders and first-time users.

projectRoot = fileparts(mfilename('fullpath'));
addpath(genpath(projectRoot));

fprintf('Project path configured. Launching main_capstone...\n\n');
main_capstone();
