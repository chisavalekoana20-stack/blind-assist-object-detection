function text_to_speech(message, cfg)
%TEXT_TO_SPEECH Speak MESSAGE aloud using the best available backend for
%the current platform, never throwing on failure (a speech backend
%outage should never crash the detection pipeline).
%
%   TEXT_TO_SPEECH(MESSAGE, CFG) uses:
%     - Windows : SAPI.SpVoice via ActiveX (native, no extra install)
%     - macOS   : the built-in `say` command
%     - Linux   : `espeak` or `spd-say` if installed on the system PATH
%
%   If CFG.speech.saveAudioFiles is true and Audio Toolbox / System
%   Object based TTS is unavailable, this falls back to printing the
%   message only (visual/log output), since MATLAB does not ship a
%   built-in cross-platform audio TTS synthesizer.
%
%   If CFG.speech.enabled is false, this is a no-op (message is still
%   printed to the console for visibility).

    if nargin < 2 || ~isfield(cfg, 'speech') || ~cfg.speech.enabled
        fprintf('[speech disabled] "%s"\n', message);
        return;
    end

    if isempty(message) || (isstring(message) && strlength(message) == 0)
        return;
    end

    message = char(message);

    try
        if ispc
            speakWindows(message, cfg);
        elseif ismac
            speakMac(message, cfg);
        else
            speakLinux(message, cfg);
        end
    catch speechErr
        warning('text_to_speech:backendFailed', ...
            'Speech playback failed (%s). Message was: "%s"', speechErr.message, message);
    end
end

function speakWindows(message, cfg)
    persistent sapiVoice
    if isempty(sapiVoice) || ~isvalid(sapiVoice)
        sapiVoice = actxserver('SAPI.SpVoice');
    end
    try
        sapiVoice.Rate = round((cfg.speech.rate - 175) / 25); % SAPI rate is roughly [-10,10]
    catch
        % Non-fatal if the rate mapping isn't supported by this SAPI version.
    end
    sapiVoice.Volume = round(cfg.speech.volume * 100);
    sapiVoice.Speak(message);
end

function speakMac(message, cfg)
    escaped = strrep(message, '"', '\"');
    cmd = sprintf('say -r %d "%s"', round(cfg.speech.rate), escaped);
    [status, cmdOut] = system(cmd);
    if status ~= 0
        error('text_to_speech:sayFailed', 'macOS "say" command failed: %s', cmdOut);
    end
end

function speakLinux(message, cfg)
    escaped = strrep(message, '"', '\"');
    if ~isempty(which('espeak')) || system('command -v espeak >/dev/null 2>&1') == 0
        cmd = sprintf('espeak -s %d "%s"', round(cfg.speech.rate), escaped);
    elseif system('command -v spd-say >/dev/null 2>&1') == 0
        cmd = sprintf('spd-say -r %d "%s"', round((cfg.speech.rate - 175) / 3.5), escaped);
    else
        fprintf(['[text_to_speech] No supported TTS engine found on this Linux system.\n' ...
                 'Install one with: sudo apt-get install espeak\n' ...
                 'Message: "%s"\n'], message);
        return;
    end
    [status, cmdOut] = system(cmd);
    if status ~= 0
        error('text_to_speech:linuxTtsFailed', 'Linux TTS command failed: %s', cmdOut);
    end
end
