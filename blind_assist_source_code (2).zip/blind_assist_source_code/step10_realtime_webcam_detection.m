%% STEP 10: REAL-TIME WEBCAM DETECTION
% Opens a connected webcam, runs live detection frame-by-frame, displays
% an annotated live view, and speaks assistance messages as objects
% appear -- the core "real-time assistance" demo. Stops automatically
% after cfg.webcam.maxDurationSecs, or immediately if the figure window
% is closed.

if ~exist('cfg', 'var')
    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();
end

displayProjectBanner('Step 10: Real-Time Webcam Detection');

try
    if ~exist('detector', 'var')
        if isfile(cfg.paths.trainedModelFile)
            loaded = load(cfg.paths.trainedModelFile, 'detector');
            detector = loaded.detector;
        else
            error('step10:noDetector', 'No trained detector found. Run Steps 5-6 first.');
        end
    end

    if ~license('test', 'video_and_image_blockset') || isempty(which('webcam'))
        error('step10:noWebcamSupport', ...
            ['webcam() is unavailable. Install "MATLAB Support Package for USB Webcams" ' ...
             'via the Add-On Explorer to use this step.']);
    end

    camList = webcamlist; %#ok<NASGU>
    cam = webcam();
    cam.Resolution = cfg.webcam.resolution;
    fprintf('Webcam connected: %s @ %s\n', cam.Name, cam.Resolution);

    fig = figure('Name', 'Real-Time Assistance Detection (close window to stop)', 'Color', 'w');
    imgHandle = [];
    lastSpokenTime = -inf;
    startTime = tic;
    frameCount = 0;

    fprintf('Starting real-time detection loop (max %d s, press Ctrl+C or close the figure to stop)...\n\n', ...
        cfg.webcam.maxDurationSecs);

    while ishandle(fig) && toc(startTime) < cfg.webcam.maxDurationSecs
        frame = snapshot(cam);
        frameCount = frameCount + 1;

        [bboxes, scores, labels] = detect(detector, frame, ...
            'Threshold', cfg.detect.confidenceThreshold, ...
            'SelectStrongest', true);

        annotatedFrame = visualizeDetections(frame, bboxes, scores, labels, 'ShowMinimap', true);

        if isempty(imgHandle) || ~ishandle(imgHandle)
            imgHandle = imshow(annotatedFrame, 'Parent', gca(fig));
        else
            set(imgHandle, 'CData', annotatedFrame);
        end

        if cfg.webcam.displayFPSInfo
            elapsed = toc(startTime);
            fps = frameCount / max(elapsed, eps);
            title(sprintf('Live detection | %.1f fps | %d object(s)', fps, numel(labels)));
        end
        drawnow limitrate;

        nowTime = toc(startTime);
        if cfg.assistance.enabled && ~isempty(labels) && ...
                (nowTime - lastSpokenTime) >= cfg.assistance.repeatSuppressSeconds
            message = generateAssistanceMessage(bboxes, scores, labels, size(frame), cfg);
            fprintf('  [t=%5.1fs] %s\n', nowTime, message);
            if cfg.speech.enabled
                text_to_speech(message, cfg);
            end
            lastSpokenTime = nowTime;
        end
    end

    clear cam;
    if ishandle(fig)
        close(fig);
    end

    fprintf('\nReal-time session ended after %.1f s (%d frames processed).\n\n', toc(startTime), frameCount);
    logMessage(cfg, 'INFO', 'Step 10 complete: %.1f s session, %d frames.', toc(startTime), frameCount);

catch ME
    if exist('cam', 'var')
        clear cam;
    end
    logMessage(cfg, 'ERROR', 'Step 10 failed: %s', ME.message);
    rethrow(ME);
end
