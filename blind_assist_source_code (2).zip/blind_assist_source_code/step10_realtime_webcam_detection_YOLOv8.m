%% STEP 10 (YOLOv8/ONNX version): REAL-TIME WEBCAM DETECTION
% Same as original step10_realtime_webcam_detection.m, but uses the
% imported YOLOv8 dlnetwork via detectYOLOv8() instead of MATLAB's
% built-in yolov4ObjectDetector. Now also includes room detection
% (speech, debounced) and a proximity beep for the nearest object.
%
% NOTE: dlnetwork inference per-frame is generally slower than a native
% yolov4ObjectDetector, especially on CPU. If FPS is too low, try:
%   - lowering cam.Resolution in project_config()
%   - running on a machine with a supported GPU (net will use it
%     automatically via predict() if available)

if ~exist('cfg', 'var')
    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();
end

displayProjectBanner('Step 10 (YOLOv8): Real-Time Webcam Detection');

ONNX_MODEL_PATH = fullfile(cfg.paths.modelsDir, 'best.onnx'); % <-- adjust if needed

% --- Tuning for room-announcement debounce (avoid flicker/repeats) ---
ROOM_STABILITY_FRAMES = 3;   % consecutive frames a room must persist before it's spoken

try
    if ~exist('net', 'var')
        fprintf('Importing YOLOv8 ONNX model from %s...\n', ONNX_MODEL_PATH);
        net = importNetworkFromONNX(ONNX_MODEL_PATH);
    end
    classNames = getYOLOv8ClassNames();

    if ~license('test', 'video_and_image_blockset') || isempty(which('webcam'))
        error('step10:noWebcamSupport', ...
            ['webcam() is unavailable. Install "MATLAB Support Package for USB Webcams" ' ...
             'via the Add-On Explorer to use this step.']);
    end

    camList = webcamlist; %#ok<NASGU>
    cam = webcam();
    cam.Resolution = cfg.webcam.resolution;
    fprintf('Webcam connected: %s @ %s\n', cam.Name, cam.Resolution);

    fig = figure('Name', 'Real-Time Assistance Detection (close window to stop)', 'Color', 'w');
    imgHandle = [];
    lastSpokenTime = -inf;
    startTime = tic;
    frameCount = 0;

    % --- Room detection state ---
    lastSpokenRoom   = '';
    pendingRoom      = '';
    pendingRoomCount = 0;

    % --- Beep rate state (proximity -> min seconds between beeps) ---
    beepIntervals = containers.Map( ...
        {'very close', 'close', 'nearby', 'far'}, ...
        {0.15,         0.4,     0.9,       Inf});
    lastBeepTic = 0;

    fprintf('Starting real-time detection loop (max %d s, press Ctrl+C or close the figure to stop)...\n\n', ...
        cfg.webcam.maxDurationSecs);

    while ishandle(fig) && toc(startTime) < cfg.webcam.maxDurationSecs

        frame = snapshot(cam);
        frameCount = frameCount + 1;

        [bboxes, scores, labels] = detectYOLOv8(net, frame, classNames, ...
            'Threshold', cfg.detect.confidenceThreshold, ...
            'SelectStrongest', true, ...
            'OverlapThreshold', cfg.detect.overlapThreshold);

        annotatedFrame = visualizeDetections(frame, bboxes, scores, labels, 'ShowMinimap', true);
        if isempty(imgHandle) || ~ishandle(imgHandle)
            imgHandle = imshow(annotatedFrame, 'Parent', gca(fig));
        else
            set(imgHandle, 'CData', annotatedFrame);
        end

        if cfg.webcam.displayFPSInfo
            elapsed = toc(startTime);
            fps = frameCount / max(elapsed, eps);
            title(sprintf('Live detection | %.1f fps | %d object(s)', fps, numel(labels)));
        end
        drawnow limitrate;

        nowTime = toc(startTime);

        % --- Proximity beep for the single nearest/most urgent object ---
        if ~isempty(labels)
            sceneInfo = assistance_layer(bboxes, scores, labels, size(frame), cfg);
            nearest = sceneInfo(1);
            requiredInterval = beepIntervals(nearest.proximity);
            if isfinite(requiredInterval) && elapsedSinceTic(lastBeepTic) > requiredInterval
                playProximityBeep(nearest.proximity);
                lastBeepTic = tic;
            end
        end

        % --- Room detection with debounce ---
        currentRoom = generateRoomMessage(labels, cfg);
        if strcmp(currentRoom, pendingRoom)
            pendingRoomCount = pendingRoomCount + 1;
        else
            pendingRoom = currentRoom;
            pendingRoomCount = 1;
        end
        if pendingRoomCount >= ROOM_STABILITY_FRAMES && ~strcmp(pendingRoom, lastSpokenRoom) ...
                && ~isempty(pendingRoom)
            fprintf('  [t=%5.1fs] Room: %s\n', nowTime, pendingRoom);
            if cfg.speech.enabled
                text_to_speech(pendingRoom, cfg);
            end
            lastSpokenRoom = pendingRoom;
        end

        % --- Object/assistance message (existing repeat-suppress logic) ---
        if cfg.assistance.enabled && ~isempty(labels) && ...
                (nowTime - lastSpokenTime) >= cfg.assistance.repeatSuppressSeconds
            message = generateAssistanceMessage(bboxes, scores, labels, size(frame), cfg);
            fprintf('  [t=%5.1fs] %s\n', nowTime, message);
            if cfg.speech.enabled
                text_to_speech(message, cfg);
            end
            lastSpokenTime = nowTime;
        end
    end

    clear cam;
    if ishandle(fig)
        close(fig);
    end

    fprintf('\nReal-time session ended after %.1f s (%d frames processed).\n\n', toc(startTime), frameCount);
    logMessage(cfg, 'INFO', 'Step 10 (YOLOv8) complete: %.1f s session, %d frames.', toc(startTime), frameCount);

catch ME
    if exist('cam', 'var')
        clear cam;
    end
    logMessage(cfg, 'ERROR', 'Step 10 (YOLOv8) failed: %s', ME.message);
    rethrow(ME);
end

function elapsed = elapsedSinceTic(t)
%ELAPSEDSINCETIC Returns elapsed time since T (a tic value), or Inf if
%T==0 (i.e. no beep has played yet, so the first one is never delayed).
    if isequal(t, 0)
        elapsed = Inf;
    else
        elapsed = toc(t);
    end
end
