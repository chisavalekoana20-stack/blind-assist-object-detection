%% STEP 1: DATASET INSPECTION
% Scans dataset/everydayObjectDataset, reports image counts, formats,
% resolutions, and flags any corrupt or unreadable files, before any
% organization or annotation work begins.
%
% Can be run standalone (it loads its own config) or called from
% main_capstone.m.

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 1: Dataset Inspection');
logMessage(cfg, 'INFO', 'Starting dataset inspection at %s', cfg.paths.datasetDir);

try
    if ~exist(cfg.paths.datasetDir, 'dir')
        error('step1:datasetMissing', ...
            ['Dataset folder not found: %s\n' ...
             'Place your raw images inside dataset/everydayObjectDataset/ before running this step.'], ...
             cfg.paths.datasetDir);
    end

    allFiles = dir(cfg.paths.datasetDir);
    allFiles = allFiles(~[allFiles.isdir]);

    isImage = false(numel(allFiles), 1);
    for k = 1:numel(allFiles)
        [~, ~, ext] = fileparts(allFiles(k).name);
        isImage(k) = any(strcmpi(ext, cfg.imageFileExtensions));
    end
    imageFiles = allFiles(isImage);

    fprintf('Found %d files total, %d recognized as images.\n', numel(allFiles), numel(imageFiles));

    if isempty(imageFiles)
        warning('step1:noImages', ...
            'No images found in %s. Add images before continuing to Step 1b.', cfg.paths.datasetDir);
    end

    widths  = nan(numel(imageFiles), 1);
    heights = nan(numel(imageFiles), 1);
    sizesKB = nan(numel(imageFiles), 1);
    corruptFiles = {};

    fprintf('Inspecting %d image files...\n', numel(imageFiles));
    for k = 1:numel(imageFiles)
        fPath = fullfile(cfg.paths.datasetDir, imageFiles(k).name);
        try
            info = imfinfo(fPath);
            widths(k)  = info.Width;
            heights(k) = info.Height;
            sizesKB(k) = imageFiles(k).bytes / 1024;
        catch readErr
            corruptFiles{end+1} = imageFiles(k).name; %#ok<AGROW>
            logMessage(cfg, 'WARN', 'Unreadable/corrupt image: %s (%s)', imageFiles(k).name, readErr.message);
        end

        if mod(k, max(1, round(numel(imageFiles)/10))) == 0 || k == numel(imageFiles)
            fprintf('  Progress: %d / %d (%.0f%%)\n', k, numel(imageFiles), 100*k/numel(imageFiles));
        end
    end

    validMask = ~isnan(widths);

    fprintf('\n----- DATASET SUMMARY -----\n');
    fprintf('Valid images        : %d\n', sum(validMask));
    fprintf('Corrupt/unreadable  : %d\n', numel(corruptFiles));
    if any(validMask)
        fprintf('Resolution range    : %dx%d  to  %dx%d\n', ...
            min(widths(validMask)), min(heights(validMask)), ...
            max(widths(validMask)), max(heights(validMask)));
        fprintf('Mean resolution     : %.0fx%.0f\n', mean(widths(validMask)), mean(heights(validMask)));
        fprintf('Mean file size      : %.1f KB\n', mean(sizesKB(validMask)));
        fprintf('Total dataset size  : %.1f MB\n', sum(sizesKB(validMask))/1024);
    end
    if ~isempty(corruptFiles)
        fprintf('Corrupt files:\n');
        fprintf('  - %s\n', corruptFiles{:});
    end
    fprintf('----------------------------\n\n');

    logMessage(cfg, 'INFO', 'Dataset inspection complete: %d valid, %d corrupt.', ...
        sum(validMask), numel(corruptFiles));

catch ME
    logMessage(cfg, 'ERROR', 'Step 1 failed: %s', ME.message);
    rethrow(ME);
end
