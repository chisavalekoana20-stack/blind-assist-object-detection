%% STEP 1b: ORGANIZE DATASET
% Renames files to a consistent scheme (img_00001.jpg, img_00002.jpg, ...),
% removes any files flagged as unreadable in Step 1, and ensures every
% image is a supported extension/color format (converts grayscale/RGBA
% to standard RGB JPEG) so downstream labeling and training behave
% consistently.

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 1b: Organize Dataset');
logMessage(cfg, 'INFO', 'Organizing dataset in %s', cfg.paths.datasetDir);

try
    if ~exist(cfg.paths.datasetDir, 'dir')
        error('step1b:datasetMissing', 'Dataset folder not found: %s', cfg.paths.datasetDir);
    end

    allFiles = dir(cfg.paths.datasetDir);
    allFiles = allFiles(~[allFiles.isdir]);
    isImage = false(numel(allFiles), 1);
    for k = 1:numel(allFiles)
        [~, ~, ext] = fileparts(allFiles(k).name);
        isImage(k) = any(strcmpi(ext, cfg.imageFileExtensions));
    end
    imageFiles = allFiles(isImage);

    if isempty(imageFiles)
        warning('step1b:noImages', 'No images to organize in %s.', cfg.paths.datasetDir);
        return;
    end

    % Sort by original name for deterministic renumbering.
    [~, order] = sort({imageFiles.name});
    imageFiles = imageFiles(order);

    organizedDir = fullfile(cfg.paths.datasetDir, 'organized');
    if ~exist(organizedDir, 'dir')
        mkdir(organizedDir);
    end

    skipped = {};
    renamed = 0;

    fprintf('Organizing %d images into: %s\n', numel(imageFiles), organizedDir);
    for k = 1:numel(imageFiles)
        srcPath = fullfile(cfg.paths.datasetDir, imageFiles(k).name);
        newName = sprintf('img_%05d.jpg', k);
        dstPath = fullfile(organizedDir, newName);

        try
            img = imread(srcPath);

            % Standardize color format to RGB uint8.
            if size(img, 3) == 1
                img = repmat(img, 1, 1, 3);
            elseif size(img, 3) == 4
                img = img(:, :, 1:3);
            end
            if ~isa(img, 'uint8')
                img = im2uint8(img);
            end

            imwrite(img, dstPath, 'jpg', 'Quality', 95);
            renamed = renamed + 1;
        catch orgErr
            skipped{end+1} = imageFiles(k).name; %#ok<AGROW>
            logMessage(cfg, 'WARN', 'Skipped unreadable file during organization: %s (%s)', ...
                imageFiles(k).name, orgErr.message);
        end

        if mod(k, max(1, round(numel(imageFiles)/10))) == 0 || k == numel(imageFiles)
            fprintf('  Progress: %d / %d (%.0f%%)\n', k, numel(imageFiles), 100*k/numel(imageFiles));
        end
    end

    fprintf('\nOrganized %d images successfully. %d skipped.\n', renamed, numel(skipped));
    fprintf('Organized images written to: %s\n', organizedDir);
    fprintf(['NOTE: Original files were left untouched in %s. Point the Image Labeler\n' ...
             '(Step 2) at the "organized" subfolder for a clean, consistently-named set.\n\n'], ...
             cfg.paths.datasetDir);

    logMessage(cfg, 'INFO', 'Step 1b complete: %d organized, %d skipped.', renamed, numel(skipped));

catch ME
    logMessage(cfg, 'ERROR', 'Step 1b failed: %s', ME.message);
    rethrow(ME);
end
