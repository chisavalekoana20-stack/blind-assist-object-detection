%% STEP 2: IMAGE ANNOTATION
% The MATLAB Image Labeler is an interactive app -- it cannot be scripted
% end-to-end. This step prepares everything needed (an imageDatastore
% pointed at the organized images) and launches the app, then explains
% exactly what to do and where to export the result so Step 3 can pick
% it up automatically.

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 2: Image Annotation (Image Labeler)');

try
    organizedDir = fullfile(cfg.paths.datasetDir, 'organized');
    if exist(organizedDir, 'dir') && ~isempty(dir(fullfile(organizedDir, '*.jpg')))
        labelSourceDir = organizedDir;
    else
        labelSourceDir = cfg.paths.datasetDir;
        logMessage(cfg, 'WARN', ...
            'No organized/ folder found -- run Step 1b first for consistent filenames. Falling back to raw dataset dir.');
    end

    imds = imageDatastore(labelSourceDir, 'FileExtensions', cfg.imageFileExtensions);
    fprintf('Prepared imageDatastore with %d images from:\n  %s\n\n', numel(imds.Files), labelSourceDir);

    fprintf('Suggested label classes (from project_config.m):\n');
    for c = 1:numel(cfg.classNames)
        fprintf('   %2d. %s\n', c, cfg.classNames{c});
    end

    fprintf(['\n--------------------------------------------------------------\n' ...
             'MANUAL STEP REQUIRED\n' ...
             '--------------------------------------------------------------\n' ...
             '1. The Image Labeler app will open (or run imageLabeler(imds) if not).\n' ...
             '2. Click "ROI Labels" -> "Label" -> add each class above as a\n' ...
             '   Rectangle ROI label.\n' ...
             '3. Draw bounding boxes around every relevant object in each\n' ...
             '   frame you want to use for training.\n' ...
             '4. When finished: App Toolstrip -> Export -> "To File..."\n' ...
             '5. Save the exported groundTruth object as:\n' ...
             '   %s\n' ...
             '6. Re-run main_capstone.m (or step3_convert_labels_for_yolo.m)\n' ...
             '   once gTruth.mat exists.\n' ...
             '--------------------------------------------------------------\n\n'], ...
             cfg.paths.gTruthFile);

    if exist(cfg.paths.gTruthFile, 'file')
        fprintf('A gTruth.mat already exists at the expected path -- you can skip\n');
        fprintf('re-labeling and proceed directly to Step 3 if it is up to date.\n\n');
    end

    if usejava('desktop') && license('test', 'video_and_image_blockset')
        try
            imageLabeler(imds);
            logMessage(cfg, 'INFO', 'Image Labeler launched with %d images.', numel(imds.Files));
        catch launchErr
            logMessage(cfg, 'WARN', 'Could not auto-launch Image Labeler: %s', launchErr.message);
            fprintf('Launch it manually with:\n   imageLabeler(imds)\n\n');
        end
    else
        fprintf(['No interactive desktop/toolbox detected in this session.\n' ...
                 'Run the following manually in a desktop MATLAB session:\n' ...
                 '   imds = imageDatastore(''%s'');\n   imageLabeler(imds);\n\n'], labelSourceDir);
    end

catch ME
    logMessage(cfg, 'ERROR', 'Step 2 failed: %s', ME.message);
    rethrow(ME);
end
