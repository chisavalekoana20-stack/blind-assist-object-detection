%% STEP 3: CONVERT LABELS FOR YOLO
% Loads gTruth.mat (exported from the Image Labeler in Step 2), converts
% it into an objectDetectorTrainingData table via loadGroundTruth, cleans
% up any rows with zero boxes, and saves the result as trainingData.mat
% for the split step.

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 3: Convert Labels for YOLO');

try
    trainingData = loadGroundTruth(cfg.paths.gTruthFile); %#ok<NASGU>

    % Drop rows with no bounding boxes at all across every class column.
    numRows = height(trainingData);
    keepMask = false(numRows, 1);
    for r = 1:numRows
        rowHasBoxes = false;
        for c = 2:width(trainingData)
            if ~isempty(trainingData{r, c}{1})
                rowHasBoxes = true;
                break;
            end
        end
        keepMask(r) = rowHasBoxes;
    end

    droppedCount = sum(~keepMask);
    if droppedCount > 0
        fprintf('Dropping %d image(s) with zero labeled boxes.\n', droppedCount);
        trainingData = trainingData(keepMask, :); %#ok<NASGU>
    end

    % Verify referenced image files actually exist (paths inside gTruth
    % are absolute and can go stale if the dataset was moved).
    missing = {};
    for r = 1:height(trainingData)
        if ~isfile(trainingData.imageFilename{r})
            missing{end+1} = trainingData.imageFilename{r}; %#ok<AGROW>
        end
    end
    if ~isempty(missing)
        warning('step3:missingImages', ...
            ['%d image file(s) referenced in gTruth.mat could not be found on disk.\n' ...
             'These rows will cause errors during training/splitting. First missing file:\n  %s'], ...
             numel(missing), missing{1});
    end

    save(cfg.paths.trainingDataFile, 'trainingData');
    fprintf('Saved YOLO-ready training table (%d rows, %d classes) to:\n  %s\n\n', ...
        height(trainingData), width(trainingData) - 1, cfg.paths.trainingDataFile);

    logMessage(cfg, 'INFO', 'Step 3 complete: %d rows saved to trainingData.mat.', height(trainingData));

catch ME
    logMessage(cfg, 'ERROR', 'Step 3 failed: %s', ME.message);
    rethrow(ME);
end
