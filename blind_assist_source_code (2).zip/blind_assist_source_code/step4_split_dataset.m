%% STEP 4: SPLIT DATASET
% Splits trainingData.mat into train/validation/test tables using the
% ratios in project_config.m, with a fixed random seed for
% reproducibility. Saves each split to its own .mat file.

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 4: Split Dataset');

try
    ratioSum = cfg.split.trainRatio + cfg.split.valRatio + cfg.split.testRatio;
    if abs(ratioSum - 1.0) > 1e-6
        error('step4:badRatios', ...
            'Split ratios must sum to 1.0 (currently %.4f). Check project_config.m.', ratioSum);
    end

    if ~isfile(cfg.paths.trainingDataFile)
        error('step4:missingTrainingData', ...
            'trainingData.mat not found. Run Step 3 first.\n  Expected at: %s', cfg.paths.trainingDataFile);
    end

    loaded = load(cfg.paths.trainingDataFile, 'trainingData');
    trainingData = loaded.trainingData;

    rng(cfg.split.randomSeed);
    numRows = height(trainingData);
    shuffledIdx = randperm(numRows);

    numTrain = round(cfg.split.trainRatio * numRows);
    numVal   = round(cfg.split.valRatio * numRows);
    numTest  = numRows - numTrain - numVal;

    if numTrain < 1 || numVal < 1 || numTest < 1
        warning('step4:tinyDataset', ...
            ['Dataset is very small (%d images) -- one or more splits may end up empty.\n' ...
             'Consider labeling more images before training.'], numRows);
    end

    trainIdx = shuffledIdx(1:numTrain);
    valIdx   = shuffledIdx(numTrain+1 : numTrain+numVal);
    testIdx  = shuffledIdx(numTrain+numVal+1 : end);

    trainData = trainingData(trainIdx, :); %#ok<NASGU>
    validationData = trainingData(valIdx, :); %#ok<NASGU>
    testData = trainingData(testIdx, :); %#ok<NASGU>

    save(cfg.paths.trainDataFile, 'trainData');
    save(cfg.paths.validationDataFile, 'validationData');
    save(cfg.paths.testDataFile, 'testData');

    fprintf('Dataset split complete (seed = %d):\n', cfg.split.randomSeed);
    fprintf('  Train      : %4d images (%.0f%%) -> %s\n', numTrain, 100*numTrain/numRows, cfg.paths.trainDataFile);
    fprintf('  Validation : %4d images (%.0f%%) -> %s\n', numVal, 100*numVal/numRows, cfg.paths.validationDataFile);
    fprintf('  Test       : %4d images (%.0f%%) -> %s\n\n', numTest, 100*numTest/numRows, cfg.paths.testDataFile);

    logMessage(cfg, 'INFO', 'Step 4 complete: %d train / %d val / %d test.', numTrain, numVal, numTest);

catch ME
    logMessage(cfg, 'ERROR', 'Step 4 failed: %s', ME.message);
    rethrow(ME);
end
