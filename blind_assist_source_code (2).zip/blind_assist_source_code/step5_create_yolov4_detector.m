%% STEP 5: CREATE YOLOv4 DETECTOR
% Estimates anchor boxes from the training split (via k-means) and
% constructs an untrained yolov4ObjectDetector using the base network
% and input size specified in project_config.m. Saves the anchors for
% reuse/inspection and keeps the detector object in memory for Step 6.

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 5: Create YOLOv4 Detector');

try
    if ~isfile(cfg.paths.trainDataFile)
        error('step5:missingTrainData', ...
            'trainData.mat not found. Run Step 4 first.\n  Expected at: %s', cfg.paths.trainDataFile);
    end

    loaded = load(cfg.paths.trainDataFile, 'trainData');
    trainData = loaded.trainData;

    fprintf('Resizing training data to network input size (%dx%d) before anchor estimation...\n', ...
        cfg.model.inputSize(1), cfg.model.inputSize(2));
    trainImgDS = imageDatastore(trainData.imageFilename);
    trainBoxDS = boxLabelDatastore(trainData(:, 2:end));
    trainCombinedForAnchors = combine(trainImgDS, trainBoxDS);
    trainCombinedForAnchors = transform(trainCombinedForAnchors, ...
        @(d) preprocessForYOLO(d, cfg.model.inputSize));

    fprintf('Estimating anchor boxes from %d training images (%d heads, %d anchors)...\n', ...
        height(trainData), cfg.model.numHeads, cfg.model.numAnchors);
    anchorBoxes = estimateAnchors(trainCombinedForAnchors, cfg.model.numAnchors, cfg.model.numHeads); %#ok<NASGU>
    save(cfg.paths.anchorBoxesFile, 'anchorBoxes');
    fprintf('Anchor boxes saved to: %s\n\n', cfg.paths.anchorBoxesFile);

    classNames = cfg.classNames;

    fprintf('Building yolov4ObjectDetector:\n');
    fprintf('  Base network : %s\n', cfg.model.baseNetwork);
    fprintf('  Input size   : %d x %d x %d\n', cfg.model.inputSize);
    fprintf('  Classes (%d) : %s\n\n', numel(classNames), strjoin(classNames, ', '));

    detector = yolov4ObjectDetector( ...
        cfg.model.baseNetwork, ...
        classNames, ...
        anchorBoxes, ...
        'InputSize', cfg.model.inputSize);

    fprintf('Untrained YOLOv4 detector created successfully.\n');
    fprintf('This detector is held in the "detector" variable for Step 6 (training).\n\n');

    logMessage(cfg, 'INFO', 'Step 5 complete: detector built on base network "%s".', cfg.model.baseNetwork);

catch ME
    logMessage(cfg, 'ERROR', 'Step 5 failed: %s', ME.message);
    if contains(ME.identifier, 'MATLAB:undefinedVarOrFunction') || contains(ME.message, 'yolov4ObjectDetector')
        fprintf(2, ['\nHint: yolov4ObjectDetector requires Computer Vision Toolbox and\n' ...
                    'Deep Learning Toolbox, plus the "Computer Vision Toolbox Model for\n' ...
                    'YOLO v4 Object Detection" support package. Install it via the Add-On\n' ...
                    'Explorer if this error persists.\n\n']);
    end
    rethrow(ME);
end