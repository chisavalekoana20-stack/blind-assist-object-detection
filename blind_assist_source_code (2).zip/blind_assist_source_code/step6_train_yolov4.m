%% STEP 6: TRAIN YOLOv4
% Trains the detector built in Step 5 using trainingOptions tuned from
% project_config.m. Applies augmentation (Step 6a), sets up checkpoints
% so a crashed/interrupted session can resume, and saves the final
% trained detector to models/trainedYOLOv4.mat.

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 6: Train YOLOv4');

try
    if ~exist('detector', 'var')
        error('step6:noDetector', ...
            'No "detector" variable found in the workspace. Run Step 5 first to build it.');
    end
    if ~isfile(cfg.paths.trainDataFile) || ~isfile(cfg.paths.validationDataFile)
        error('step6:missingSplits', ...
            'trainData.mat / validationData.mat not found. Run Step 4 first.');
    end

    trainLoaded = load(cfg.paths.trainDataFile, 'trainData');
    valLoaded = load(cfg.paths.validationDataFile, 'validationData');
    trainData = trainLoaded.trainData;
    validationData = valLoaded.validationData;

    trainDS = boxLabelDatastore(trainData(:, 2:end));
    trainImgDS = imageDatastore(trainData.imageFilename);
    trainCombined = combine(trainImgDS, trainDS);
    trainCombined = transform(trainCombined, @(d) preprocessForYOLO(d, cfg.model.inputSize));

    valDS = boxLabelDatastore(validationData(:, 2:end));
    valImgDS = imageDatastore(validationData.imageFilename);
    valCombined = combine(valImgDS, valDS);
    valCombined = transform(valCombined, @(d) preprocessForYOLO(d, cfg.model.inputSize));

    if cfg.train.useAugmentation
        fprintf('Applying data augmentation to the training set...\n');
        trainCombined = transform(trainCombined, @augmentData);
    end

    if ~exist(cfg.train.checkpointPath, 'dir')
        mkdir(cfg.train.checkpointPath);
    end

    options = trainingOptions('sgdm', ...
        'MiniBatchSize', cfg.train.miniBatchSize, ...
        'MaxEpochs', cfg.train.maxEpochs, ...
        'InitialLearnRate', cfg.train.learningRate, ...
        'LearnRateSchedule', cfg.train.learnRateSchedule, ...
        'LearnRateDropFactor', cfg.train.learnRateDropFactor, ...
        'LearnRateDropPeriod', cfg.train.learnRateDropPeriod, ...
        'L2Regularization', cfg.train.l2Regularization, ...
        'Momentum', cfg.train.momentum, ...
        'Shuffle', cfg.train.shuffle, ...
        'VerboseFrequency', cfg.train.verboseFrequency, ...
        'ValidationData', valCombined, ...
        'ValidationFrequency', max(1, floor(height(trainData) / cfg.train.miniBatchSize)), ...
        'CheckpointPath', cfg.train.checkpointPath, ...
        'ExecutionEnvironment', cfg.train.executionEnvironment, ...
        'GradientThreshold', 1, ...
        'Plots', 'training-progress');

    fprintf('Starting training: %d epochs, mini-batch %d, base network "%s".\n', ...
        cfg.train.maxEpochs, cfg.train.miniBatchSize, cfg.model.baseNetwork);
    fprintf('Checkpoints will be written to: %s\n', cfg.train.checkpointPath);
    fprintf('This may take a while depending on your hardware (GPU strongly recommended).\n\n');

    logMessage(cfg, 'INFO', 'Training started: %d epochs.', cfg.train.maxEpochs);
    trainingStart = tic;

    [detector, trainingInfo] = trainYOLOv4ObjectDetector(trainCombined, detector, options); %#ok<ASGLU>

    elapsedMin = toc(trainingStart) / 60;
    fprintf('\nTraining complete in %.1f minutes.\n', elapsedMin);

    save(cfg.paths.trainedModelFile, 'detector', 'trainingInfo', 'cfg');
    fprintf('Trained detector saved to: %s\n\n', cfg.paths.trainedModelFile);

    logMessage(cfg, 'INFO', 'Step 6 complete: training finished in %.1f min, model saved.', elapsedMin);

catch ME
    logMessage(cfg, 'ERROR', 'Step 6 failed: %s', ME.message);
    fprintf(2, ['\nIf training crashed partway through, check %s for the latest\n' ...
                'checkpoint (net_checkpoint__*.mat) and resume manually with\n' ...
                'trainYOLOv4ObjectDetector(..., ''CheckpointPath'', ...).\n\n'], cfg.train.checkpointPath);
    rethrow(ME);
end