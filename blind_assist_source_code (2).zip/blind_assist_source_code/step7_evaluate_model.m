%% STEP 7: EVALUATE MODEL
% Runs the trained detector over the held-out test set, computes
% per-class Average Precision / mAP / F1 via calculateMetrics, and
% produces publication-quality Precision-Recall plots and a summary bar
% chart, saved into results/evaluation_results/.

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 7: Evaluate Model');

try
    if ~exist('detector', 'var')
        if isfile(cfg.paths.trainedModelFile)
            fprintf('Loading trained detector from %s...\n', cfg.paths.trainedModelFile);
            loaded = load(cfg.paths.trainedModelFile, 'detector');
            detector = loaded.detector;
        else
            error('step7:noDetector', ...
                'No detector in memory and no trained model file found at %s. Run Step 6 first.', ...
                cfg.paths.trainedModelFile);
        end
    end

    if ~isfile(cfg.paths.testDataFile)
        error('step7:missingTestData', 'testData.mat not found. Run Step 4 first.');
    end
    loaded = load(cfg.paths.testDataFile, 'testData');
    testData = loaded.testData;

    testImgDS = imageDatastore(testData.imageFilename);
    testBoxDS = boxLabelDatastore(testData(:, 2:end));

    fprintf('Running detector over %d test images (evaluation threshold >= %.3f)...\n', ...
        height(testData), 0.01);
    fprintf('NOTE: evaluation uses a very low confidence threshold (not cfg.detect.confidenceThreshold)\n');
    fprintf('      so the precision-recall curve reflects the full range of detections.\n\n');

    results = table('Size', [height(testData) 3], ...
        'VariableTypes', {'cell', 'cell', 'cell'}, ...
        'VariableNames', {'Boxes', 'Scores', 'Labels'});

    reset(testImgDS);
    for i = 1:numel(testImgDS.Files)
        img = readimage(testImgDS, i);

        % Ensure 3-channel RGB (some real-world datasets mix in
        % grayscale/CMYK/RGBA images) -- detect() requires the exact
        % channel count the network was built with.
        if size(img, 3) == 1
            img = repmat(img, 1, 1, 3);
        elseif size(img, 3) == 4
            img = img(:, :, 1:3);
        end

        [bboxes, scores, labels] = detect(detector, img, ...
            'Threshold', 0.01, ...
            'SelectStrongest', true);
        results.Boxes{i} = bboxes;
        results.Scores{i} = scores;
        results.Labels{i} = labels;

        if mod(i, max(1, round(numel(testImgDS.Files)/10))) == 0
            fprintf('  Progress: %d / %d (%.0f%%)\n', i, numel(testImgDS.Files), 100*i/numel(testImgDS.Files));
        end
    end

    metrics = calculateMetrics(results, testBoxDS, cfg.classNames);

    % ---------------- Publication-quality plots ----------------
    numClasses = numel(cfg.classNames);
    figPR = figure('Name', 'Precision-Recall Curves', 'Color', 'w', 'Position', [100 100 900 700]);
    tiledlayout(ceil(numClasses/3), 3, 'TileSpacing', 'compact', 'Padding', 'compact');
    for c = 1:numClasses
        nexttile;
        if ~isempty(metrics.recall{c})
            plot(metrics.recall{c}, metrics.precision{c}, 'LineWidth', 2, 'Color', [0.10 0.40 0.75]);
        end
        grid on; box on;
        xlim([0 1]); ylim([0 1]);
        title(sprintf('%s (AP=%.2f)', cfg.classNames{c}, metrics.averagePrecision(c)), 'FontSize', 10);
        xlabel('Recall', 'FontSize', 9);
        ylabel('Precision', 'FontSize', 9);
    end
    sgtitle(sprintf('Precision-Recall Curves per Class (mAP = %.3f)', metrics.meanAP), 'FontWeight', 'bold');

    figBar = figure('Name', 'AP by Class', 'Color', 'w', 'Position', [150 150 800 450]);
    bar(categorical(cfg.classNames), metrics.averagePrecision, 'FaceColor', [0.20 0.55 0.35]);
    grid on; ylim([0 1]);
    ylabel('Average Precision');
    title(sprintf('Average Precision by Class (mAP = %.3f)', metrics.meanAP), 'FontWeight', 'bold');
    xtickangle(30);

    metrics.figHandle = figPR; %#ok<STRNU>
    savedPath = saveResults(metrics, 'evaluation', 'yolov4_evaluation', cfg);
    exportgraphics(figBar, fullfile(cfg.paths.evaluationResultsDir, ...
        sprintf('ap_by_class_%s.png', datestr(now, 'yyyymmdd_HHMMSS'))), 'Resolution', 200);

    fprintf('\n===== EVALUATION SUMMARY =====\n');
    fprintf('Mean Average Precision (mAP @ IoU=%.2f): %.4f\n', cfg.eval.iouThreshold, metrics.meanAP);
    for c = 1:numClasses
        fprintf('  %-12s AP = %.4f | F1 = %.4f\n', cfg.classNames{c}, metrics.averagePrecision(c), metrics.f1Score(c));
    end
    fprintf('===============================\n\n');
    fprintf('Metrics + plots saved under: %s\n\n', cfg.paths.evaluationResultsDir);

    logMessage(cfg, 'INFO', 'Step 7 complete: mAP = %.4f (results in %s).', metrics.meanAP, savedPath);

catch ME
    logMessage(cfg, 'ERROR', 'Step 7 failed: %s', ME.message);
    rethrow(ME);
end