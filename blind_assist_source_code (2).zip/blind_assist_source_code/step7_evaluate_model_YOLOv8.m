%% STEP 7 (YOLOv8/ONNX version): EVALUATE MODEL
% Same as original step7_evaluate_model.m, but uses the imported YOLOv8
% dlnetwork (from Kaggle -> ONNX -> MATLAB) via detectYOLOv8() instead of
% MATLAB's built-in yolov4ObjectDetector.
%
% CHANGES FROM ORIGINAL:
%  - Loads 'net' (dlnetwork) instead of 'detector' (yolov4ObjectDetector)
%  - classNames comes from getYOLOv8ClassNames() instead of cfg.classNames
%    (edit ONNX_MODEL_PATH below to point at your best.onnx)
%  - detect(detector, img, ...) replaced with detectYOLOv8(net, img, classNames, ...)

if ~exist('cfg', 'var')
    addpath('config', 'utilities');
    cfg = project_config();
end

displayProjectBanner('Step 7 (YOLOv8): Evaluate Model');

ONNX_MODEL_PATH = fullfile(cfg.paths.modelsDir, 'best.onnx'); % <-- adjust if needed

try
    if ~exist('net', 'var')
        fprintf('Importing YOLOv8 ONNX model from %s...\n', ONNX_MODEL_PATH);
        net = importNetworkFromONNX(ONNX_MODEL_PATH);
    end
    classNames = getYOLOv8ClassNames();

    if ~isfile(cfg.paths.testDataFile)
        error('step7:missingTestData', 'testData.mat not found. Run Step 4 first.');
    end
    loaded = load(cfg.paths.testDataFile, 'testData');
    testData = loaded.testData;

    testImgDS = imageDatastore(testData.imageFilename);
    testBoxDS = boxLabelDatastore(testData(:, 2:end));

    fprintf('Running detector over %d test images (evaluation threshold >= %.3f)...\n', ...
        height(testData), 0.01);
    fprintf('NOTE: evaluation uses a very low confidence threshold so the\n');
    fprintf('      precision-recall curve reflects the full range of detections.\n\n');

    results = table('Size', [height(testData) 3], ...
        'VariableTypes', {'cell', 'cell', 'cell'}, ...
        'VariableNames', {'Boxes', 'Scores', 'Labels'});

    reset(testImgDS);
    for i = 1:numel(testImgDS.Files)
        img = readimage(testImgDS, i);

        [bboxes, scores, labels] = detectYOLOv8(net, img, classNames, ...
            'Threshold', 0.01, ...
            'SelectStrongest', true);
        results.Boxes{i} = bboxes;
        results.Scores{i} = scores;
        results.Labels{i} = labels;

        if mod(i, max(1, round(numel(testImgDS.Files)/10))) == 0
            fprintf('  Progress: %d / %d (%.0f%%)\n', i, numel(testImgDS.Files), 100*i/numel(testImgDS.Files));
        end
    end

    metrics = calculateMetrics(results, testBoxDS, classNames);

    % ---------------- Publication-quality plots ----------------
    numClasses = numel(classNames);
    figPR = figure('Name', 'Precision-Recall Curves', 'Color', 'w', 'Position', [100 100 900 700]);
    tiledlayout(ceil(numClasses/3), 3, 'TileSpacing', 'compact', 'Padding', 'compact');
    for c = 1:numClasses
        nexttile;
        if ~isempty(metrics.recall{c})
            plot(metrics.recall{c}, metrics.precision{c}, 'LineWidth', 2, 'Color', [0.10 0.40 0.75]);
        end
        grid on; box on;
        xlim([0 1]); ylim([0 1]);
        title(sprintf('%s (AP=%.2f)', classNames{c}, metrics.averagePrecision(c)), 'FontSize', 10);
        xlabel('Recall', 'FontSize', 9);
        ylabel('Precision', 'FontSize', 9);
    end
    sgtitle(sprintf('Precision-Recall Curves per Class (mAP = %.3f)', metrics.meanAP), 'FontWeight', 'bold');

    figBar = figure('Name', 'AP by Class', 'Color', 'w', 'Position', [150 150 800 450]);
    bar(categorical(classNames), metrics.averagePrecision, 'FaceColor', [0.20 0.55 0.35]);
    grid on; ylim([0 1]);
    ylabel('Average Precision');
    title(sprintf('Average Precision by Class (mAP = %.3f)', metrics.meanAP), 'FontWeight', 'bold');
    xtickangle(30);

    metrics.figHandle = figPR; %#ok<STRNU>
    savedPath = saveResults(metrics, 'evaluation', 'yolov8_evaluation', cfg);
    exportgraphics(figBar, fullfile(cfg.paths.evaluationResultsDir, ...
        sprintf('ap_by_class_%s.png', datestr(now, 'yyyymmdd_HHMMSS'))), 'Resolution', 200);

    fprintf('\n===== EVALUATION SUMMARY =====\n');
    fprintf('Mean Average Precision (mAP @ IoU=%.2f): %.4f\n', cfg.eval.iouThreshold, metrics.meanAP);
    for c = 1:numClasses
        fprintf('  %-14s AP = %.4f | F1 = %.4f\n', classNames{c}, metrics.averagePrecision(c), metrics.f1Score(c));
    end
    fprintf('===============================\n\n');
    fprintf('Metrics + plots saved under: %s\n\n', cfg.paths.evaluationResultsDir);

    logMessage(cfg, 'INFO', 'Step 7 (YOLOv8) complete: mAP = %.4f (results in %s).', metrics.meanAP, savedPath);

catch ME
    logMessage(cfg, 'ERROR', 'Step 7 (YOLOv8) failed: %s', ME.message);
    rethrow(ME);
end
