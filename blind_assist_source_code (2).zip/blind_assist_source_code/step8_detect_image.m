%% STEP 8: DETECT IMAGE
% Runs the trained detector on a single image (input.jpg by default),
% draws + saves the annotated result, and feeds detections through the
% assistance layer to produce a spoken scene description.

if ~exist('cfg', 'var')
    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();
end

displayProjectBanner('Step 8: Detect Objects in Image');

try
    if ~exist('detector', 'var')
        if isfile(cfg.paths.trainedModelFile)
            loaded = load(cfg.paths.trainedModelFile, 'detector');
            detector = loaded.detector;
        else
            error('step8:noDetector', 'No trained detector found. Run Steps 5-6 first.');
        end
    end

    imagePath = cfg.paths.sampleImage;
    if ~isfile(imagePath)
        error('step8:missingImage', ...
            'Sample image not found at %s. Place an image there or edit cfg.paths.sampleImage.', imagePath);
    end

    fprintf('Reading image: %s\n', imagePath);
    img = imread(imagePath);

    fprintf('Running detection (confidence >= %.2f, NMS overlap <= %.2f)...\n', ...
        cfg.detect.confidenceThreshold, cfg.detect.overlapThreshold);
    [bboxes, scores, labels] = detect(detector, img, ...
        'Threshold', cfg.detect.confidenceThreshold, ...
        'SelectStrongest', true);

    fprintf('Detected %d object(s):\n', numel(labels));
    for k = 1:numel(labels)
        fprintf('  %2d. %-12s confidence = %.2f  box = [%d %d %d %d]\n', ...
            k, string(labels(k)), scores(k), bboxes(k,1), bboxes(k,2), bboxes(k,3), bboxes(k,4));
    end

    annotated = visualizeDetections(img, bboxes, scores, labels, 'ShowMinimap', true);
    savedPath = saveResults(annotated, 'image', 'detected_input', cfg);

    figure('Name', 'Detection Result', 'Color', 'w');
    imshow(annotated);
    title(sprintf('%d objects detected', numel(labels)));

    if cfg.assistance.enabled
        message = generateAssistanceMessage(bboxes, scores, labels, size(img), cfg);
        fprintf('\nAssistance message:\n  "%s"\n\n', message);
        if cfg.speech.enabled
            text_to_speech(message, cfg);
        end
    end

    fprintf('Annotated image saved to: %s\n\n', savedPath);
    logMessage(cfg, 'INFO', 'Step 8 complete: %d objects detected in %s.', numel(labels), imagePath);

catch ME
    logMessage(cfg, 'ERROR', 'Step 8 failed: %s', ME.message);
    rethrow(ME);
end
