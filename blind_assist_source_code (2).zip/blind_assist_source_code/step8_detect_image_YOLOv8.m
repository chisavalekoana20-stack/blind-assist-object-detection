%% STEP 8 (YOLOv8/ONNX version): DETECT IMAGE
% Same as original step8_detect_image.m, but uses the imported YOLOv8
% dlnetwork (from Kaggle -> ONNX -> MATLAB) via detectYOLOv8() instead of
% MATLAB's built-in yolov4ObjectDetector.

if ~exist('cfg', 'var')
    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();
end

displayProjectBanner('Step 8 (YOLOv8): Detect Objects in Image');

ONNX_MODEL_PATH = fullfile(cfg.paths.modelsDir, 'best.onnx'); % <-- adjust if needed

try
    if ~exist('net', 'var')
        fprintf('Importing YOLOv8 ONNX model from %s...\n', ONNX_MODEL_PATH);
        net = importNetworkFromONNX(ONNX_MODEL_PATH);
    end

    classNames = getYOLOv8ClassNames();
    imagePath = cfg.paths.sampleImage;

    if ~isfile(imagePath)
        error('step8:missingImage', ...
            'Sample image not found at %s. Place an image there or edit cfg.paths.sampleImage.', imagePath);
    end

    fprintf('Reading image: %s\n', imagePath);
    img = imread(imagePath);

    fprintf('Running detection (confidence >= %.2f, NMS overlap <= %.2f)...\n', ...
        cfg.detect.confidenceThreshold, cfg.detect.overlapThreshold);

    [bboxes, scores, labels] = detectYOLOv8(net, img, classNames, ...
        'Threshold', cfg.detect.confidenceThreshold, ...
        'SelectStrongest', true, ...
        'OverlapThreshold', cfg.detect.overlapThreshold);

    fprintf('Detected %d object(s):\n', numel(labels));
    for k = 1:numel(labels)
        fprintf('  %2d. %-12s confidence = %.2f  box = [%d %d %d %d]\n', ...
            k, string(labels(k)), scores(k), bboxes(k,1), bboxes(k,2), bboxes(k,3), bboxes(k,4));
    end

    annotated = visualizeDetections(img, bboxes, scores, labels, 'ShowMinimap', true);
    savedPath = saveResults(annotated, 'image', 'detected_input', cfg);

    figure('Name', 'Detection Result', 'Color', 'w');
    imshow(annotated);
    title(sprintf('%d objects detected', numel(labels)));

    if cfg.assistance.enabled
        message = generateAssistanceMessage(bboxes, scores, labels, size(img), cfg);
        fprintf('\nAssistance message:\n  "%s"\n\n', message);
        if cfg.speech.enabled
            text_to_speech(message, cfg);
        end
    end

    % --- Room detection ---
    roomMessage = generateRoomMessage(labels, cfg);
    if ~isempty(roomMessage)
        fprintf('Room message:\n  "%s"\n\n', roomMessage);
        if cfg.speech.enabled
            text_to_speech(roomMessage, cfg);
        end
    else
        fprintf('Room message: (no defining room objects detected)\n\n');
    end

    fprintf('Annotated image saved to: %s\n\n', savedPath);
    logMessage(cfg, 'INFO', 'Step 8 (YOLOv8) complete: %d objects detected in %s.', numel(labels), imagePath);

catch ME
    logMessage(cfg, 'ERROR', 'Step 8 (YOLOv8) failed: %s', ME.message);
    rethrow(ME);
end