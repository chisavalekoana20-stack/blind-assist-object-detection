%% STEP 8b (YOLOv8/ONNX version): DETECT OBJECTS IN A FOLDER OF IMAGES
% Cycle through every image in cfg.paths.testImagesDir one at a time.
% After each image is detected/annotated/spoken, type "next" to move on
% to the next image, or "exit" to stop early. No renaming files to
% input.jpg needed -- just drop as many images as you like into the
% folder and step through them.

if ~exist('cfg', 'var')
    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();
end

displayProjectBanner('Step 8b (YOLOv8): Detect Objects in a Folder of Images');

ONNX_MODEL_PATH = fullfile(cfg.paths.modelsDir, 'best.onnx'); % <-- adjust if needed

try
    if ~exist('net', 'var')
        fprintf('Importing YOLOv8 ONNX model from %s...\n', ONNX_MODEL_PATH);
        net = importNetworkFromONNX(ONNX_MODEL_PATH);
    end
    classNames = getYOLOv8ClassNames();

    imagesDir = cfg.paths.testImagesDir;
    if ~isfolder(imagesDir)
        error('step8b:missingFolder', ...
            'Folder not found at %s. Create it and add some images first.', imagesDir);
    end

    % Gather every image file in the folder matching known extensions
    allFiles = dir(imagesDir);
    allFiles = allFiles(~[allFiles.isdir]);
    imageFiles = {};
    for i = 1:numel(allFiles)
        [~, ~, ext] = fileparts(allFiles(i).name);
        if any(strcmpi(ext, cfg.imageFileExtensions))
            imageFiles{end+1} = fullfile(imagesDir, allFiles(i).name); %#ok<AGROW>
        end
    end

    if isempty(imageFiles)
        error('step8b:noImages', ...
            'No images found in %s. Supported extensions: %s', ...
            imagesDir, strjoin(cfg.imageFileExtensions, ', '));
    end

    fprintf('Found %d image(s) in %s\n', numel(imageFiles), imagesDir);
    fprintf('After each image, type "next" to continue, or "exit" to stop.\n\n');

    fig = figure('Name', 'Batch Detection', 'Color', 'w');

    for idx = 1:numel(imageFiles)
        imagePath = imageFiles{idx};
        [~, fname, fext] = fileparts(imagePath);

        fprintf('--------------------------------------------------------------\n');
        fprintf('Image %d of %d: %s%s\n', idx, numel(imageFiles), fname, fext);

        img = imread(imagePath);

        [bboxes, scores, labels] = detectYOLOv8(net, img, classNames, ...
            'Threshold', cfg.detect.confidenceThreshold, ...
            'SelectStrongest', true, ...
            'OverlapThreshold', cfg.detect.overlapThreshold);

        fprintf('Detected %d object(s):\n', numel(labels));
        for k = 1:numel(labels)
            fprintf('  %2d. %-12s confidence = %.2f\n', k, string(labels(k)), scores(k));
        end

        annotated = visualizeDetections(img, bboxes, scores, labels, 'ShowMinimap', true);
        savedPath = saveResults(annotated, 'image', sprintf('detected_%s', fname), cfg);

        if ishandle(fig)
            figure(fig);
            imshow(annotated);
            title(sprintf('Image %d of %d: %s%s -- %d objects detected', ...
                idx, numel(imageFiles), fname, fext, numel(labels)));
            drawnow;
        end

        if cfg.assistance.enabled
            message = generateAssistanceMessage(bboxes, scores, labels, size(img), cfg);
            fprintf('\nAssistance message:\n  "%s"\n', message);
            if cfg.speech.enabled
                text_to_speech(message, cfg);
            end
        end

        roomMessage = generateRoomMessage(labels, cfg);
        if ~isempty(roomMessage)
            fprintf('Room message:\n  "%s"\n', roomMessage);
            if cfg.speech.enabled
                text_to_speech(roomMessage, cfg);
            end
        end

        fprintf('Annotated image saved to: %s\n\n', savedPath);
        logMessage(cfg, 'INFO', 'Step 8b (YOLOv8) processed %s: %d objects detected.', imagePath, numel(labels));

        % --- Wait for user input before moving to the next image ---
        if idx < numel(imageFiles)
            userInput = input('Type "next" to continue, or "exit" to stop: ', 's');
            if any(strcmpi(strtrim(userInput), {'exit', 'quit', 'q'}))
                fprintf('Stopping batch detection early.\n');
                break;
            end
        end
    end

    if ishandle(fig)
        close(fig);
    end

    fprintf('\nBatch detection complete.\n\n');
    logMessage(cfg, 'INFO', 'Step 8b (YOLOv8) batch run complete: %d image(s) processed.', numel(imageFiles));

catch ME
    logMessage(cfg, 'ERROR', 'Step 8b (YOLOv8) failed: %s', ME.message);
    rethrow(ME);
end
