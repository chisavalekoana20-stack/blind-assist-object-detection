%% STEP 9: DETECT VIDEO
% Processes input.mp4 frame-by-frame, running detection + annotation on
% each frame, writes an annotated output video, and periodically
% triggers the assistance layer to narrate the scene (throttled so it
% doesn't speak on every single frame).

if ~exist('cfg', 'var')
    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();
end

displayProjectBanner('Step 9: Detect Objects in Video');

try
    if ~exist('detector', 'var')
        if isfile(cfg.paths.trainedModelFile)
            loaded = load(cfg.paths.trainedModelFile, 'detector');
            detector = loaded.detector;
        else
            error('step9:noDetector', 'No trained detector found. Run Steps 5-6 first.');
        end
    end

    videoPath = cfg.paths.sampleVideo;
    if ~isfile(videoPath)
        error('step9:missingVideo', ...
            'Sample video not found at %s. Place a video there or edit cfg.paths.sampleVideo.', videoPath);
    end

    reader = VideoReader(videoPath); %#ok<TNMLP>
    fprintf('Processing video: %s\n', videoPath);
    fprintf('  Duration: %.1f s | Frame rate: %.1f fps | Resolution: %dx%d\n', ...
        reader.Duration, reader.FrameRate, reader.Width, reader.Height);

    numFrames = floor(reader.Duration * reader.FrameRate);
    frames = cell(1, numFrames);
    frameIdx = 0;
    lastSpokenTime = -inf;

    fprintf('Running detection frame-by-frame (assistance narration every %d s)...\n', ...
        cfg.assistance.repeatSuppressSeconds);

    while hasFrame(reader)
        frameIdx = frameIdx + 1;
        frame = readFrame(reader);

        [bboxes, scores, labels] = detect(detector, frame, ...
            'Threshold', cfg.detect.confidenceThreshold, ...
            'SelectStrongest', true);

        annotatedFrame = visualizeDetections(frame, bboxes, scores, labels);
        frames{frameIdx} = annotatedFrame;

        currentTime = reader.CurrentTime;
        if cfg.assistance.enabled && ~isempty(labels) && ...
                (currentTime - lastSpokenTime) >= cfg.assistance.repeatSuppressSeconds
            message = generateAssistanceMessage(bboxes, scores, labels, size(frame), cfg);
            fprintf('  [t=%5.1fs] %s\n', currentTime, message);
            if cfg.speech.enabled
                text_to_speech(message, cfg);
            end
            lastSpokenTime = currentTime;
        end

        if mod(frameIdx, max(1, round(numFrames/20))) == 0
            fprintf('  Progress: frame %d / %d (%.0f%%)\n', frameIdx, numFrames, 100*frameIdx/numFrames);
        end
    end
    frames = frames(1:frameIdx);

    videoData = struct('frames', {frames}, 'frameRate', reader.FrameRate);
    savedPath = saveResults(videoData, 'video', 'detected_input', cfg);

    fprintf('\nProcessed %d frames. Annotated video saved to:\n  %s\n\n', frameIdx, savedPath);
    logMessage(cfg, 'INFO', 'Step 9 complete: %d frames processed from %s.', frameIdx, videoPath);

catch ME
    logMessage(cfg, 'ERROR', 'Step 9 failed: %s', ME.message);
    rethrow(ME);
end
