%% STEP 9 (YOLOv8/ONNX version): DETECT OBJECTS + ROOM IN A VIDEO
% Walk-through demo (first-person perspective): reads a video file frame
% by frame, runs YOLOv8 detection on sampled frames, plays a proximity
% beep for the nearest/most urgent object each sampled frame, and speaks
% room/object announcements only when they actually change -- so
% standing still doesn't cause repeated or overlapping speech.

if ~exist('cfg', 'var')
    addpath('config', 'utilities', 'assistance', 'speech');
    cfg = project_config();
end

displayProjectBanner('Step 9 (YOLOv8): Detect Objects + Room in Video');

ONNX_MODEL_PATH = fullfile(cfg.paths.modelsDir, 'best.onnx'); % <-- adjust if needed

% --- Tuning parameters for the walk-through demo ---
FRAME_SAMPLE_RATE   = 15;  % run detection every Nth frame (~2x/sec at 30fps)
STABILITY_FRAMES    = 2;   % how many consecutive sampled frames a room must
                           % persist for before it's spoken (debounce flicker)

try
    if ~exist('net', 'var')
        fprintf('Importing YOLOv8 ONNX model from %s...\n', ONNX_MODEL_PATH);
        net = importNetworkFromONNX(ONNX_MODEL_PATH);
    end

    classNames = getYOLOv8ClassNames();
    videoPath = cfg.paths.sampleVideo;

    if ~isfile(videoPath)
        error('step9:missingVideo', ...
            'Sample video not found at %s. Place a video there or edit cfg.paths.sampleVideo.', videoPath);
    end

    fprintf('Reading video: %s\n', videoPath);
    vr = VideoReader(videoPath);

    outputDir = cfg.paths.detectedVideosDir;
    if ~isfolder(outputDir)
        mkdir(outputDir);
    end
    outPath = fullfile(outputDir, 'detected_walkthrough.mp4');
    vw = VideoWriter(outPath, 'MPEG-4');
    vw.FrameRate = vr.FrameRate;
    open(vw);

    % --- State tracking across frames ---
    lastSpokenRoom     = '';
    pendingRoom        = '';
    pendingRoomCount   = 0;
    lastSpokenObjects  = string([]);

    frameIdx = 0;
    logEntries = {};  % {timestamp, message} pairs for the capstone transcript

    fprintf('Processing frames (sampling every %d frames)...\n', FRAME_SAMPLE_RATE);

    while hasFrame(vr)
        frame = readFrame(vr);
        frameIdx = frameIdx + 1;
        timestampSec = frameIdx / vr.FrameRate;

        if mod(frameIdx, FRAME_SAMPLE_RATE) ~= 0
            writeVideo(vw, frame);   % keep original frame for smooth output
            continue;
        end

        [bboxes, scores, labels] = detectYOLOv8(net, frame, classNames, ...
            'Threshold', cfg.detect.confidenceThreshold, ...
            'SelectStrongest', true, ...
            'OverlapThreshold', cfg.detect.overlapThreshold);

        % Filter to classes we actually want to report, if configured
        if isfield(cfg, 'reportClassNames') && ~isempty(cfg.reportClassNames)
            keepIdx = ismember(string(labels), string(cfg.reportClassNames));
            bboxes = bboxes(keepIdx, :);
            scores = scores(keepIdx);
            labels = labels(keepIdx);
        end

        annotated = visualizeDetections(frame, bboxes, scores, labels, 'ShowMinimap', false);
        writeVideo(vw, annotated);

        % --- Proximity beep for the single nearest/most urgent object ---
        sceneInfo = assistance_layer(bboxes, scores, labels, size(frame), cfg);
        if ~isempty(sceneInfo)
            playProximityBeep(sceneInfo(1).proximity);  % sceneInfo(1) = highest priority
        end

        % --- Room detection with debounce ---
        currentRoom = generateRoomMessage(labels, cfg);

        if strcmp(currentRoom, pendingRoom)
            pendingRoomCount = pendingRoomCount + 1;
        else
            pendingRoom = currentRoom;
            pendingRoomCount = 1;
        end

        if pendingRoomCount >= STABILITY_FRAMES && ~strcmp(pendingRoom, lastSpokenRoom) ...
                && ~isempty(pendingRoom)
            fprintf('[%.1fs] Room message: "%s"\n', timestampSec, pendingRoom);
            if cfg.speech.enabled
                text_to_speech(pendingRoom, cfg);
            end
            logEntries{end+1} = sprintf('%6.1fs  ROOM: %s', timestampSec, pendingRoom); %#ok<AGROW>
            lastSpokenRoom = pendingRoom;
        end

        % --- Object detection: only announce genuinely NEW objects ---
        currentObjects = unique(string(labels), 'stable');
        newObjects = setdiff(currentObjects, lastSpokenObjects);

        if ~isempty(newObjects) && cfg.assistance.enabled
            objMessage = generateAssistanceMessage(bboxes, scores, labels, size(frame), cfg);
            fprintf('[%.1fs] Assistance message: "%s"\n', timestampSec, objMessage);
            if cfg.speech.enabled
                text_to_speech(objMessage, cfg);
            end
            logEntries{end+1} = sprintf('%6.1fs  OBJECTS: %s', timestampSec, objMessage); %#ok<AGROW>
        end

        lastSpokenObjects = union(lastSpokenObjects, currentObjects);
    end

    close(vw);

    fprintf('\nAnnotated walkthrough video saved to: %s\n', outPath);

    % --- Save a transcript of everything announced, for the capstone report ---
    logPath = fullfile(cfg.paths.evaluationResultsDir, 'walkthrough_transcript.txt');
    fid = fopen(logPath, 'w');
    fprintf(fid, 'Walkthrough Transcript -- %s\n\n', videoPath);
    for i = 1:numel(logEntries)
        fprintf(fid, '%s\n', logEntries{i});
    end
    fclose(fid);
    fprintf('Transcript saved to: %s\n\n', logPath);

    logMessage(cfg, 'INFO', 'Step 9 (YOLOv8) complete: processed %d frames from %s.', frameIdx, videoPath);

catch ME
    logMessage(cfg, 'ERROR', 'Step 9 (YOLOv8) failed: %s', ME.message);
    rethrow(ME);
end