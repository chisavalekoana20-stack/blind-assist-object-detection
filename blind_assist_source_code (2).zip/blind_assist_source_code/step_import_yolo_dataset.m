function step_import_yolo_dataset(yoloRootPath, className)
%STEP_IMPORT_YOLO_DATASET Import a pre-annotated YOLO-format dataset
%(images/train, images/val, labels/train, labels/val) directly into
%trainData.mat / validationData.mat / testData.mat, completely bypassing
%Steps 1-4 (no manual labeling in the Image Labeler needed).
%
%   STEP_IMPORT_YOLO_DATASET(YOLOROOTPATH, CLASSNAME) where YOLOROOTPATH
%   points to a folder with this structure:
%       yoloRootPath/
%       ├── images/train/   (.jpg/.png)
%       ├── images/val/     (.jpg/.png)
%       ├── labels/train/   (.txt, YOLO format, same filename as image)
%       └── labels/val/     (.txt, YOLO format, same filename as image)
%
%   CLASSNAME is the name to assign to every box found (e.g. 'person') --
%   this dataset is assumed to be single-class. If your labels/*.txt
%   files contain multiple different class_id values, only class_id 0 is
%   kept by default; edit the "TARGET_CLASS_ID" constant below if your
%   person class uses a different id.
%
%   After running this, go straight to Step 5 (main_capstone('train')
%   will still work, or run step5_create_yolov4_detector.m directly) --
%   Steps 1-4 are not needed for this data.
%
%   The existing val/ split is used for BOTH validation and test (split
%   50/50) since the YOLO dataset only ships two splits, not three. This
%   is a reasonable simplification but means your test set is smaller
%   than the pipeline's usual 15% -- worth knowing when interpreting
%   Step 7's evaluation results.

    addpath('config', 'utilities');
    cfg = project_config(); %#ok<NASGU>

    if nargin < 2
        className = 'person';
    end

    TARGET_CLASS_ID = 0; % change if your person class uses a different YOLO class_id

    fprintf('Importing YOLO-format dataset from: %s\n', yoloRootPath);
    fprintf('Assigning class name "%s" to class_id = %d\n\n', className, TARGET_CLASS_ID);

    trainData = importSplit(fullfile(yoloRootPath, 'images', 'train'), ...
                             fullfile(yoloRootPath, 'labels', 'train'), ...
                             className, TARGET_CLASS_ID, 'train'); %#ok<NASGU>

    valDataFull = importSplit(fullfile(yoloRootPath, 'images', 'val'), ...
                               fullfile(yoloRootPath, 'labels', 'val'), ...
                               className, TARGET_CLASS_ID, 'val');

    % Split the val set 50/50 into validation + test since YOLO datasets
    % typically only provide two splits.
    numVal = height(valDataFull);
    rng(42);
    shuffled = randperm(numVal);
    half = floor(numVal / 2);
    validationData = valDataFull(shuffled(1:half), :); %#ok<NASGU>
    testData = valDataFull(shuffled(half+1:end), :); %#ok<NASGU>

    save(fullfile(cfg.projectRoot, 'trainData.mat'), 'trainData');
    save(fullfile(cfg.projectRoot, 'validationData.mat'), 'validationData');
    save(fullfile(cfg.projectRoot, 'testData.mat'), 'testData');

    fprintf('\nImport complete:\n');
    fprintf('  Train      : %4d images -> trainData.mat\n', height(trainData));
    fprintf('  Validation : %4d images -> validationData.mat\n', height(validationData));
    fprintf('  Test       : %4d images -> testData.mat\n\n', height(testData));
    fprintf(['IMPORTANT: update cfg.classNames in config/project_config.m to include\n' ...
             '''%s'' before running Step 5, if it is not already there.\n\n'], className);
    fprintf('Next: run step5_create_yolov4_detector.m (or main_capstone(''train'')).\n\n');
end

function dataTable = importSplit(imgDir, labelDir, className, targetClassId, splitName)
    if ~isfolder(imgDir)
        error('step_import_yolo_dataset:missingImgDir', 'Image folder not found: %s', imgDir);
    end
    if ~isfolder(labelDir)
        error('step_import_yolo_dataset:missingLabelDir', 'Label folder not found: %s', labelDir);
    end

    imgFiles = [dir(fullfile(imgDir, '*.jpg')); dir(fullfile(imgDir, '*.jpeg')); ...
                dir(fullfile(imgDir, '*.png'))];

    fprintf('Importing %s split: %d image files found in %s\n', splitName, numel(imgFiles), imgDir);

    imageFilenames = cell(numel(imgFiles), 1);
    boxCells = cell(numel(imgFiles), 1);
    keepMask = true(numel(imgFiles), 1);

    for i = 1:numel(imgFiles)
        imgPath = fullfile(imgDir, imgFiles(i).name);
        [~, baseName, ~] = fileparts(imgFiles(i).name);
        labelPath = fullfile(labelDir, [baseName '.txt']);

        try
            img = imread(imgPath); %#ok<NASGU> -- read fully to catch unsupported formats (e.g. CMYK JPEGs) upfront
            info = imfinfo(imgPath);
            imgWidth = info.Width;
            imgHeight = info.Height;
        catch readErr
            keepMask(i) = false;
            fprintf('  Skipping unreadable image: %s (%s)\n', imgFiles(i).name, readErr.message);
            continue;
        end

        [bboxes, classIds] = loadYoloLabels(labelPath, imgWidth, imgHeight);

        if ~isempty(classIds)
            keep = classIds == targetClassId;
            bboxes = bboxes(keep, :);
        end

        if isempty(bboxes)
            keepMask(i) = false; % drop images with no matching-class boxes
            continue;
        end

        imageFilenames{i} = imgPath;
        boxCells{i} = bboxes;

        if mod(i, max(1, round(numel(imgFiles)/10))) == 0
            fprintf('  Progress: %d / %d (%.0f%%)\n', i, numel(imgFiles), 100*i/numel(imgFiles));
        end
    end

    imageFilenames = imageFilenames(keepMask);
    boxCells = boxCells(keepMask);

    fprintf('  Kept %d / %d images with at least one "%s" box.\n\n', ...
        numel(imageFilenames), numel(imgFiles), className);

    dataTable = table(imageFilenames, boxCells, 'VariableNames', {'imageFilename', className});
end