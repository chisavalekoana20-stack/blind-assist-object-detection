function subsampleTrainingData(numImages)
%SUBSAMPLETRAININGDATA Randomly reduce trainData.mat down to NUMIMAGES
%rows, in place. Useful when the full imported dataset is too large to
%train on a slower/CPU-only machine in a reasonable time.
%
%   SUBSAMPLETRAININGDATA(NUMIMAGES) loads trainData.mat from the project
%   root, randomly samples NUMIMAGES rows (or all of them if the table
%   already has fewer), and overwrites trainData.mat with the reduced
%   version. validationData.mat and testData.mat are left untouched.

    addpath('config');
    cfg = project_config();

    if ~isfile(cfg.paths.trainDataFile)
        error('subsampleTrainingData:missingFile', 'trainData.mat not found at %s', cfg.paths.trainDataFile);
    end

    loaded = load(cfg.paths.trainDataFile, 'trainData');
    trainData = loaded.trainData;

    originalCount = height(trainData);

    if numImages >= originalCount
        fprintf('trainData.mat already has %d images (<= requested %d) -- no change made.\n', ...
            originalCount, numImages);
        return;
    end

    rng(42);
    idx = randperm(originalCount, numImages);
    trainData = trainData(idx, :); %#ok<NASGU>

    save(cfg.paths.trainDataFile, 'trainData');

    fprintf('Reduced trainData.mat from %d to %d images.\n', originalCount, numImages);
    fprintf('validationData.mat and testData.mat were left unchanged.\n\n');
end