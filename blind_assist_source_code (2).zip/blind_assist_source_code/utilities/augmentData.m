function dataOut = augmentData(data)
%AUGMENTDATA Apply randomized augmentation to one training example.
%   DATAOUT = AUGMENTDATA(DATA) takes a 1-by-3 cell {img, bboxes, labels}
%   (the standard format used inside a transform() pipeline on a
%   boxLabelDatastore-backed datastore) and returns an augmented version:
%     - random horizontal flip
%     - random scale (0.8x - 1.2x) with box rescaling
%     - random brightness / contrast jitter
%     - random Gaussian noise (occasionally)
%   Bounding boxes are clipped back to valid image bounds and any boxes
%   that become degenerate (zero width/height) after transformation are
%   dropped, along with their corresponding labels.
%
%   Designed to be used as:
%       augmentedData = transform(trainingData, @augmentData);

    dataOut = data;
    img = data{1};
    bboxes = data{2};
    labels = data{3};

    if isempty(bboxes)
        dataOut = {img, bboxes, labels};
        return;
    end

    sz = size(img);

    % --- Random horizontal flip ---
    if rand() > 0.5
        img = fliplr(img);
        bboxes(:,1) = sz(2) - bboxes(:,1) - bboxes(:,3);
    end

    % --- Random brightness / contrast jitter ---
    if rand() > 0.5
        img = jitterColorHSV(img, ...
            'Brightness', 0.15, ...
            'Contrast', 0.15, ...
            'Saturation', 0.1);
    end

    % --- Occasional Gaussian noise for robustness ---
    if rand() > 0.75
        img = imnoise(img, 'gaussian', 0, 0.001);
    end

    % --- Random scale with bbox rescale ---
    if rand() > 0.5
        scaleFactor = 0.8 + 0.4 * rand(); % [0.8, 1.2]
        img = imresize(img, scaleFactor);
        newSz = size(img);
        bboxes = bboxes * scaleFactor;

        % Re-pad/crop back to original size so batches stay uniform.
        img = imresize(img, [sz(1) sz(2)]);
        scaleX = sz(2) / newSz(2);
        scaleY = sz(1) / newSz(1);
        bboxes(:,[1 3]) = bboxes(:,[1 3]) * scaleX;
        bboxes(:,[2 4]) = bboxes(:,[2 4]) * scaleY;
    end

    % --- Clip boxes to image bounds and drop degenerate boxes ---
    bboxes(:,1) = max(bboxes(:,1), 1);
    bboxes(:,2) = max(bboxes(:,2), 1);
    bboxes(:,3) = min(bboxes(:,3), sz(2) - bboxes(:,1));
    bboxes(:,4) = min(bboxes(:,4), sz(1) - bboxes(:,2));

    valid = bboxes(:,3) > 1 & bboxes(:,4) > 1;
    bboxes = bboxes(valid, :);
    labels = labels(valid, :);

    dataOut = {img, bboxes, labels};
end
