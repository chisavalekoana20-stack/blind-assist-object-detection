function metrics = calculateMetrics(detectionResults, testData, classNames)
%CALCULATEMETRICS Compute detection performance metrics from evaluation
%results produced by evaluateDetectionPrecision / evaluateDetectionAOS.
%
%   METRICS = CALCULATEMETRICS(DETECTIONRESULTS, TESTDATA, CLASSNAMES)
%
%   DETECTIONRESULTS is a table of {Boxes, Scores, Labels} as produced by
%   running detect() over a test datastore (one row per image).
%   TESTDATA is the ground-truth table/datastore used for evaluation.
%   CLASSNAMES is a cellstr/string array of class names.
%
%   Returns a struct METRICS with fields:
%     .averagePrecision   per-class AP (vector, same order as classNames)
%     .meanAP              scalar mAP across classes
%     .precision           per-class precision cell array (curve)
%     .recall              per-class recall cell array (curve)
%     .f1Score             per-class scalar F1 at the operating point
%     .confusionCounts     struct with TP/FP/FN counts per class
%     .classNames          echoed back for convenience

if istable(testData)
        testDS = boxLabelDatastore(testData(:, 2:end));
else
        testDS = testData;
end
    numClasses = numel(classNames);
    ap = zeros(numClasses, 1);
    f1 = zeros(numClasses, 1);
    tpCounts = zeros(numClasses, 1);
    fpCounts = zeros(numClasses, 1);
    fnCounts = zeros(numClasses, 1);

    fprintf('Computing per-class Average Precision...\n');
    [ap, recallCurves, precisionCurves] = evaluateDetectionPrecision(detectionResults, testDS);

    % Normalize to cell arrays regardless of what evaluateDetectionPrecision
    % returned (single-class calls may return plain matrices instead of
    % per-class cells).
    if ~iscell(recallCurves)
        recallCurves = arrayfun(@(c) recallCurves(:,c), 1:numClasses, 'UniformOutput', false)';
    end
    if ~iscell(precisionCurves)
        precisionCurves = arrayfun(@(c) precisionCurves(:,c), 1:numClasses, 'UniformOutput', false)';
    end

for c = 1:numClasses
        recallC = recallCurves{c};
        precisionC = precisionCurves{c};
if isempty(recallC) || isempty(precisionC)
            f1(c) = 0;
continue;
end
        f1Curve = 2 * (precisionC .* recallC) ./ (precisionC + recallC + eps);
        [f1(c), bestIdx] = max(f1Curve);
        totalGT = numelGroundTruth(testDS, classNames{c});
        tpCounts(c) = round(recallC(bestIdx) * totalGT);
        fpCounts(c) = round(tpCounts(c) * (1/max(precisionC(bestIdx), eps) - 1));
        fnCounts(c) = totalGT - tpCounts(c);
        fprintf('  Class "%s": AP = %.4f | F1(best) = %.4f\n', ...
            string(classNames(c)), ap(c), f1(c));
end

    metrics.averagePrecision = ap;
    metrics.meanAP = mean(ap);
    metrics.precision = precisionCurves;  % always a cell array now
    metrics.recall = recallCurves;        % always a cell array now
    metrics.f1Score = f1;
    metrics.confusionCounts = struct('TP', tpCounts, 'FP', fpCounts, 'FN', fnCounts);
    metrics.classNames = classNames;

    fprintf('\n>>> Overall mean Average Precision (mAP): %.4f <<<\n\n', metrics.meanAP);
end

function n = numelGroundTruth(testDS, className)
    n = 0;
    reset(testDS);
while hasdata(testDS)
        d = read(testDS);
        labels = d{2};
        n = n + sum(string(labels) == string(className));
end
    reset(testDS);
end