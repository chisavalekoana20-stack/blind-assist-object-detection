function ok = checkToolboxes(verbose)
%CHECKTOOLBOXES Verify required MATLAB toolboxes/products are installed.
%   OK = CHECKTOOLBOXES() checks for the toolboxes required by the
%   capstone project (Computer Vision, Deep Learning, Image Processing,
%   and optionally Audio Toolbox for offline TTS) and returns true if all
%   required toolboxes are present. Missing toolboxes are reported to the
%   console with guidance rather than throwing, so the caller can decide
%   how to proceed.
%
%   OK = CHECKTOOLBOXES(VERBOSE) with VERBOSE = false suppresses the
%   informational "all good" messages (warnings/errors are always shown).

    if nargin < 1
        verbose = true;
    end

    required = struct( ...
        'name',      {'Computer Vision Toolbox', 'Deep Learning Toolbox', 'Image Processing Toolbox'}, ...
        'licenseId', {'video_and_image_blockset', 'neural_network_toolbox', 'image_toolbox'} ...
    );

    optional = struct( ...
        'name',      {'Audio Toolbox', 'Parallel Computing Toolbox'}, ...
        'licenseId', {'audio_system_toolbox', 'distrib_computing_toolbox'} ...
    );

    ok = true;

    for k = 1:numel(required)
        present = license('test', required(k).licenseId) && ...
                  ~isempty(ver(strtok(required(k).name)));
        % Fallback check purely on 'ver' listing since license IDs vary
        % across MATLAB releases.
        present = present || checkViaVer(required(k).name);
        if ~present
            ok = false;
            warning('checkToolboxes:missingRequired', ...
                ['Required toolbox not detected: %s.\n' ...
                 '  -> Install it via the MATLAB Add-On Explorer, or\n' ...
                 '     some functionality (YOLOv4 training/inference) will fail.'], ...
                 required(k).name);
        elseif verbose
            fprintf('  [OK] %s found.\n', required(k).name);
        end
    end

    for k = 1:numel(optional)
        present = checkViaVer(optional(k).name);
        if ~present
            if verbose
                fprintf(['  [--] Optional toolbox not found: %s ' ...
                         '(a fallback will be used where possible).\n'], optional(k).name);
            end
        elseif verbose
            fprintf('  [OK] %s found.\n', optional(k).name);
        end
    end

    if ok && verbose
        fprintf('All required toolboxes are available.\n');
    end
end

function tf = checkViaVer(niceName)
    tf = false;
    try
        v = ver;
        names = {v.Name};
        tf = any(contains(names, niceName, 'IgnoreCase', true));
    catch
        tf = false;
    end
end
