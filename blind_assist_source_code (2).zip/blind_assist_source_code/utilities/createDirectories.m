function createDirectories(cfg)
%CREATEDIRECTORIES Ensure all folders the pipeline depends on exist.
%   CREATEDIRECTORIES(CFG) takes the project config struct (see
%   project_config.m) and creates any missing directories under the
%   project root: dataset, models, results (+ subfolders), logs.
%
%   Safe to call repeatedly; existing directories are left untouched.

    folders = {
        cfg.paths.datasetDir
        cfg.paths.modelsDir
        cfg.paths.resultsDir
        cfg.paths.detectedImagesDir
        cfg.paths.detectedVideosDir
        cfg.paths.evaluationResultsDir
        cfg.paths.logsDir
    };

    for k = 1:numel(folders)
        f = folders{k};
        if ~exist(f, 'dir')
            [success, msg] = mkdir(f);
            if success
                fprintf('  [+] Created directory: %s\n', f);
            else
                warning('createDirectories:mkdirFailed', ...
                    'Could not create directory "%s": %s', f, msg);
            end
        end
    end
end
