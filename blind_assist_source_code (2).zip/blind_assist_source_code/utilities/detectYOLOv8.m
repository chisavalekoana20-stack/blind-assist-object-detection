function [bboxes, scores, labels] = detectYOLOv8(net, img, classNames, varargin)
%DETECTYOLOV8 Run a YOLOv8 dlnetwork (imported from ONNX) on an image and
%return detections in the same [bboxes, scores, labels] format that
%MATLAB's built-in detect(yolov4ObjectDetector, img) returns, so it can
%be swapped into existing pipelines with minimal changes.
%
%   [bboxes, scores, labels] = detectYOLOv8(net, img, classNames)
%   [bboxes, scores, labels] = detectYOLOv8(net, img, classNames, 'Threshold', 0.5, 'SelectStrongest', true)
%
%   net        - dlnetwork imported via importNetworkFromONNX
%   img        - HxWx3 uint8 image (RGB)
%   classNames - cell array of class name strings, in the SAME ORDER
%                used during training (class index 0 = classNames{1}, etc.)
%
%   bboxes  - Nx4 [x y w h] in original image pixel coordinates
%   scores  - Nx1 confidence scores
%   labels  - Nx1 categorical labels

    p = inputParser;
    addParameter(p, 'Threshold', 0.25);
    addParameter(p, 'SelectStrongest', true);
    addParameter(p, 'OverlapThreshold', 0.45);
    parse(p, varargin{:});
    threshold = p.Results.Threshold;
    selectStrongest = p.Results.SelectStrongest;
    overlapThreshold = p.Results.OverlapThreshold;

    inputSize = 640;

    % Ensure 3-channel RGB (mirrors the channel-fixing already in step7/8)
    if size(img, 3) == 1
        img = repmat(img, 1, 1, 3);
    elseif size(img, 3) == 4
        img = img(:, :, 1:3);
    end

    [imgLetterboxed, scale, padX, padY] = letterboxResize(img, inputSize);

    imgInput = single(imgLetterboxed) / 255;
    dlImg = dlarray(imgInput, 'SSCB');

    dlOut = predict(net, dlImg);
    outData = extractdata(dlOut);
    outData = squeeze(outData);

    numClasses = numel(classNames);

    % Ultralytics ONNX export shape is typically [4+numClasses, numBoxes]
    % (after squeeze). Transpose if needed so rows = boxes, cols = (4+nc).
    if size(outData, 1) == 4 + numClasses
        outData = outData';
    end

    if isempty(outData)
        bboxes = zeros(0, 4);
        scores = zeros(0, 1);
        labels = categorical(strings(0, 1), classNames);
        return;
    end

    boxesRaw = outData(:, 1:4);          % cx, cy, w, h (in 640x640 input space)
    classScores = outData(:, 5:end);
    [maxScores, classIdx] = max(classScores, [], 2);

    keep = maxScores >= threshold;
    boxesRaw = boxesRaw(keep, :);
    maxScores = maxScores(keep);
    classIdx = classIdx(keep);

    if isempty(boxesRaw)
        bboxes = zeros(0, 4);
        scores = zeros(0, 1);
        labels = categorical(strings(0, 1), classNames);
        return;
    end

    % Center-based -> top-left [x y w h], still in 640x640 input space
    x = boxesRaw(:, 1) - boxesRaw(:, 3) / 2;
    y = boxesRaw(:, 2) - boxesRaw(:, 4) / 2;
    w = boxesRaw(:, 3);
    h = boxesRaw(:, 4);

    % Undo letterbox padding/scaling to map back to original image coords
    x = (x - padX) / scale;
    y = (y - padY) / scale;
    w = w / scale;
    h = h / scale;

    bboxesAll = [x, y, w, h];

    if selectStrongest
        [bboxes, scores, keptClassIdx] = selectStrongestBboxMulticlass( ...
            bboxesAll, maxScores, classIdx, ...
            'RatioType', 'Union', ...
            'OverlapThreshold', overlapThreshold);
        labels = categorical(classNames(keptClassIdx), classNames);
    else
        bboxes = bboxesAll;
        scores = maxScores;
        labels = categorical(classNames(classIdx), classNames);
    end
end

function [imgOut, scale, padX, padY] = letterboxResize(img, targetSize)
%LETTERBOXRESIZE Resize + pad an image to a square targetSize x targetSize
%canvas while preserving aspect ratio (standard YOLO preprocessing).
    [h, w, c] = size(img);
    scale = min(targetSize / h, targetSize / w);
    newH = round(h * scale);
    newW = round(w * scale);
    imgResized = imresize(img, [newH, newW]);

    padX = floor((targetSize - newW) / 2);
    padY = floor((targetSize - newH) / 2);

    imgOut = uint8(114 * ones(targetSize, targetSize, c, 'like', img));
    imgOut(padY+1:padY+newH, padX+1:padX+newW, :) = imgResized;
end
