function displayProjectBanner(subtitle)
%DISPLAYPROJECTBANNER Print a formatted banner to the command window.
%   DISPLAYPROJECTBANNER() prints the default capstone banner.
%   DISPLAYPROJECTBANNER(SUBTITLE) prints the banner with a custom
%   subtitle line (e.g. the name of the current step).

    if nargin < 1
        subtitle = 'Everyday Object Detection & Assistance System';
    end

    barLine = repmat('=', 1, 70);

    fprintf('\n%s\n', barLine);
    fprintf('   AI-POWERED OBJECT DETECTION & VOICE ASSISTANCE CAPSTONE\n');
    fprintf('   %s\n', subtitle);
    fprintf('%s\n', barLine);
    fprintf('   MATLAB YOLOv4 Pipeline | %s\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));
    fprintf('%s\n\n', barLine);
end
