function [anchorBoxes, meanIoU] = estimateAnchors(trainingData, numAnchors, numHeads)
%ESTIMATEANCHORS Estimate anchor boxes for YOLOv4 via k-means clustering.
%   ANCHORBOXES = ESTIMATEANCHORS(TRAININGDATA) estimates 9 anchor boxes
%   (grouped into 3 detection heads x 3 anchors) from the bounding boxes
%   present in TRAININGDATA (a table or datastore compatible with
%   estimateAnchorBoxes).
%
%   ANCHORBOXES = ESTIMATEANCHORS(TRAININGDATA, NUMANCHORS) specifies a
%   custom number of anchors.
%
%   ANCHORBOXES = ESTIMATEANCHORS(TRAININGDATA, NUMANCHORS, NUMHEADS)
%   specifies the number of YOLOv4 detection heads to group anchors into.
%   THIS MUST MATCH THE BASE NETWORK: tiny-yolov4-coco has 2 heads;
%   csp-darknet53-coco has 3 heads. Passing the wrong number here silently
%   misaligns anchors with output heads and will badly break detection
%   even though training may appear to run/converge normally.
%
%   [ANCHORBOXES, MEANIOU] = ESTIMATEANCHORS(...) also returns the mean
%   IoU achieved by the estimated anchors, printed as a sanity check.
%
%   ANCHORBOXES is returned sorted by area (descending -- largest first,
%   matching MATLAB's YOLOv4 anchor-to-head convention) and reshaped into
%   a 1-by-NUMHEADS cell array of [3x2] boxes, ready to pass to
%   yolov4ObjectDetector.

    if nargin < 2
        numAnchors = 9;
    end
    if nargin < 3
        numHeads = 3;
    end

    if istable(trainingData)
        ds = boxLabelDatastore(trainingData(:, 2:end));
    else
        ds = trainingData;
    end

    fprintf('Estimating %d anchor boxes via k-means clustering on box sizes...\n', numAnchors);

    [anchorBoxes, meanIoU] = estimateAnchorBoxes(ds, numAnchors);

    areas = anchorBoxes(:,1) .* anchorBoxes(:,2);
    [~, order] = sort(areas, 'descend'); % LARGEST first -- matches MATLAB's
    % official YOLOv4 anchor-to-head convention: anchorBoxes{1} (the
    % largest anchors) is assigned to the first detection head. Sorting
    % ascending here was a real bug -- it silently mismatched anchor
    % scale to detection head resolution throughout training.
    anchorBoxes = anchorBoxes(order, :);

    fprintf('Estimated anchors (sorted by area, mean IoU = %.4f):\n', meanIoU);
    disp(anchorBoxes);

    if meanIoU < 0.5
        warning('estimateAnchors:lowIoU', ...
            ['Mean IoU of estimated anchors is low (%.2f). Consider ' ...
             'collecting more/varied training data or trying a different ' ...
             'number of anchors.'], meanIoU);
    end

    % Split into per-head groups (numHeads must match the base network's
    % actual number of detection heads -- see function help above).
    perHead = floor(numAnchors / numHeads);
    anchorsByHead = cell(1, numHeads);
    for h = 1:numHeads
        idxStart = (h-1)*perHead + 1;
        if h == numHeads
            idxEnd = size(anchorBoxes, 1);
        else
            idxEnd = h*perHead;
        end
        anchorsByHead{h} = anchorBoxes(idxStart:idxEnd, :);
    end

    anchorBoxes = anchorsByHead; % overwrite output with per-head grouped cell array
end