function gTruthTable = loadGroundTruth(gTruthPath)
%LOADGROUNDTRUTH Load a groundTruth object exported from the Image Labeler
%and convert it into a table suitable for YOLO training.
%
%   T = LOADGROUNDTRUTH(GTRUTHPATH) loads the .mat file at GTRUTHPATH
%   (expected to contain a variable named 'gTruth' of class groundTruth,
%   or a groundTruthMultisignal / array of groundTruth objects), validates
%   it, and returns an objectDetectorTrainingData-style table with an
%   'imageFilename' column followed by one column per label class,
%   each cell containing an M-by-4 [x y w h] bounding box matrix.
%
%   Throws a clear error if the file or variable is missing, or if no
%   labeled bounding boxes are found at all.

    if ~isfile(gTruthPath)
        error('loadGroundTruth:fileNotFound', ...
            ['Ground truth file not found: %s\n' ...
             'Export labels from the Image Labeler app (Step 2) first, ' ...
             'and save as gTruth.mat in the project root.'], gTruthPath);
    end

    data = load(gTruthPath);

    if isfield(data, 'gTruth')
        gTruthRaw = data.gTruth;
    else
        fns = fieldnames(data);
        candidate = fns(structfun(@(c) isa(data.(c), 'groundTruth'), data));
        if isempty(candidate)
            error('loadGroundTruth:variableNotFound', ...
                ['No variable of class groundTruth found in %s.\n' ...
                 'Make sure you exported the labeling session correctly.'], gTruthPath);
        end
        gTruthRaw = data.(candidate{1});
    end

    if ~isa(gTruthRaw, 'groundTruth')
        error('loadGroundTruth:invalidType', ...
            'Expected a groundTruth object, found class "%s".', class(gTruthRaw));
    end

    try
        gTruthTable = objectDetectorTrainingData(gTruthRaw);
    catch ME
        error('loadGroundTruth:conversionFailed', ...
            ['Failed to convert groundTruth to a training table: %s\n' ...
             'Check that image source paths referenced inside gTruth.mat ' ...
             'still exist on disk (they are stored as absolute paths).'], ME.message);
    end

    if isempty(gTruthTable)
        error('loadGroundTruth:empty', 'The exported ground truth contains zero rows.');
    end

    numLabelCols = width(gTruthTable) - 1;
    if numLabelCols < 1
        error('loadGroundTruth:noLabels', ...
            'No label columns found -- did you draw and label any ROIs in the Image Labeler?');
    end

    totalBoxes = 0;
    for c = 2:width(gTruthTable)
        totalBoxes = totalBoxes + sum(cellfun(@(b) size(b,1), gTruthTable{:,c}));
    end

    fprintf('Loaded ground truth: %d images, %d label classes, %d total bounding boxes.\n', ...
        height(gTruthTable), numLabelCols, totalBoxes);

    if totalBoxes == 0
        warning('loadGroundTruth:zeroBoxes', ...
            'Ground truth table loaded but contains zero bounding boxes.');
    end
end
