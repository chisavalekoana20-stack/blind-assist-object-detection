function [bboxes, classIds] = loadYoloLabels(labelFilePath, imgWidth, imgHeight)
%LOADYOLOLABELS Parse a single YOLO-format .txt label file into pixel
%bounding boxes.
%
%   [BBOXES, CLASSIDS] = LOADYOLOLABELS(LABELFILEPATH, IMGWIDTH, IMGHEIGHT)
%
%   YOLO .txt label format: one line per object,
%       class_id  x_center  y_center  width  height
%   with x_center/y_center/width/height all normalized to [0, 1] relative
%   to the image dimensions.
%
%   BBOXES is an M-by-4 matrix of [x y w h] in PIXEL coordinates (top-left
%   corner convention, matching MATLAB's bounding box format).
%   CLASSIDS is an M-by-1 numeric vector of the raw class indices found in
%   the file (0-based, as YOLO stores them).
%
%   If the label file doesn't exist or is empty (no objects in that
%   image), returns empty arrays rather than erroring -- some images in a
%   YOLO dataset legitimately have zero objects.

    bboxes = zeros(0, 4);
    classIds = zeros(0, 1);

    if ~isfile(labelFilePath)
        return;
    end

    fid = fopen(labelFilePath, 'r');
    if fid == -1
        warning('loadYoloLabels:openFailed', 'Could not open label file: %s', labelFilePath);
        return;
    end

    lines = textscan(fid, '%f %f %f %f %f', 'CollectOutput', true);
    fclose(fid);

    if isempty(lines) || isempty(lines{1})
        return;
    end

    data = lines{1}; % N-by-5: [classId, xCenterNorm, yCenterNorm, wNorm, hNorm]

    classIds = data(:, 1);
    xCenter = data(:, 2) * imgWidth;
    yCenter = data(:, 3) * imgHeight;
    w = data(:, 4) * imgWidth;
    h = data(:, 5) * imgHeight;

    x = xCenter - w/2;
    y = yCenter - h/2;

    % Clip to valid image bounds (guards against slightly-out-of-range
    % annotations at image edges).
    x = max(x, 1);
    y = max(y, 1);
    w = min(w, imgWidth - x);
    h = min(h, imgHeight - y);

    bboxes = [x, y, w, h];

    valid = w > 1 & h > 1;
    bboxes = bboxes(valid, :);
    classIds = classIds(valid);
end