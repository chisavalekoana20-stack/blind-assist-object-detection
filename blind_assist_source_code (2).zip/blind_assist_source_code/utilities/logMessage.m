function logMessage(cfg, level, fmt, varargin)
%LOGMESSAGE Write a timestamped log line to console and/or the log file.
%   LOGMESSAGE(CFG, LEVEL, FMT, ...) formats FMT with VARARGIN (sprintf
%   style) and writes it prefixed with a timestamp and LEVEL tag
%   ('INFO', 'WARN', 'ERROR', 'DEBUG') to CFG.logging.logFile (if
%   CFG.logging.enabled) and to the console (if CFG.logging.echoToConsole).
%
%   Falls back to console-only output if the log file can't be opened,
%   so a logging failure never interrupts the pipeline.

    if nargin < 2, level = 'INFO'; end
    if nargin < 3, fmt = ''; end

    msg = sprintf(fmt, varargin{:});
    line = sprintf('[%s] [%-5s] %s', datestr(now, 'yyyy-mm-dd HH:MM:SS'), upper(level), msg);

    if ~isfield(cfg, 'logging') || cfg.logging.echoToConsole
        fprintf('%s\n', line);
    end

    if isfield(cfg, 'logging') && cfg.logging.enabled
        try
            logDir = fileparts(cfg.logging.logFile);
            if ~exist(logDir, 'dir')
                mkdir(logDir);
            end
            fid = fopen(cfg.logging.logFile, 'a');
            if fid ~= -1
                fprintf(fid, '%s\n', line);
                fclose(fid);
            end
        catch loggingError
            fprintf('[logMessage] Warning: could not write to log file (%s)\n', loggingError.message);
        end
    end
end
