function playProximityBeep(proximity)
%PLAYPROXIMITYBEEP Play a short tone whose pitch reflects how close the
%nearest detected object is, similar to a car parking sensor. Silent for
%'far' since no beep should play when nothing urgent is nearby.
%
%   PLAYPROXIMITYBEEP(PROXIMITY) where PROXIMITY is one of:
%   'very close' | 'close' | 'nearby' | 'far'

    fs = 8000;  % sample rate (Hz)

    switch proximity
        case 'very close'
            freq = 1000; duration = 0.12;
        case 'close'
            freq = 700;  duration = 0.12;
        case 'nearby'
            freq = 400;  duration = 0.12;
        otherwise
            return;  % 'far' or unrecognized -> no beep
    end

    t = 0:1/fs:duration;
    tone = sin(2*pi*freq*t);
    sound(tone, fs);
end