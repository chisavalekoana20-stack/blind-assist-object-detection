function data = preprocessForYOLO(data, targetSize)
%PREPROCESSFORYOLO Resize an image and proportionally rescale its
%bounding boxes to match the detector's network input size.
%
%   DATA = PREPROCESSFORYOLO(DATA, TARGETSIZE) takes a 1-by-3 cell
%   {img, bboxes, labels} (the standard format read from a combined
%   image + box label datastore) and:
%     - resizes img to TARGETSIZE(1:2) ([height width])
%     - rescales bboxes proportionally so they still line up correctly
%       with the resized image
%
%   This MUST be applied (via transform()) before estimateAnchorBoxes and
%   before trainYOLOv4ObjectDetector whenever the source images are not
%   already all exactly TARGETSIZE. Skipping this step means anchor
%   boxes and training boxes end up in inconsistent pixel scales across
%   images of different original resolutions, which severely damages
%   detection accuracy.
%
%   Usage:
%       combinedData = combine(imageDatastore(files), boxLabelDatastore(boxes));
%       resizedData = transform(combinedData, @(d) preprocessForYOLO(d, detector.InputSize));

    img = data{1};
    bboxes = data{2};
    labels = data{3};

    origSize = size(img);
    targetH = targetSize(1);
    targetW = targetSize(2);

    scaleY = targetH / origSize(1);
    scaleX = targetW / origSize(2);

    img = imresize(img, [targetH targetW]);

    if size(img, 3) == 1
        img = repmat(img, 1, 1, 3);
    elseif size(img, 3) == 4
        img = img(:, :, 1:3);
    end

    if ~isempty(bboxes)
        bboxes(:,1) = bboxes(:,1) * scaleX;
        bboxes(:,2) = bboxes(:,2) * scaleY;
        bboxes(:,3) = bboxes(:,3) * scaleX;
        bboxes(:,4) = bboxes(:,4) * scaleY;

        bboxes(:,1) = max(bboxes(:,1), 1);
        bboxes(:,2) = max(bboxes(:,2), 1);
        bboxes(:,3) = min(bboxes(:,3), targetW - bboxes(:,1));
        bboxes(:,4) = min(bboxes(:,4), targetH - bboxes(:,2));
    end

    data = {img, bboxes, labels};
end