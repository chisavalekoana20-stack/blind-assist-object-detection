function outPath = saveResults(data, category, filenameHint, cfg)
%SAVERESULTS Save a result artifact into the correct results/ subfolder.
%   OUTPATH = SAVERESULTS(DATA, CATEGORY, FILENAMEHINT, CFG)
%
%   CATEGORY must be one of:
%     'image'      - DATA is an image matrix -> saved as PNG/JPG under
%                    results/detected_images/
%     'video'      - DATA is a VideoWriter-compatible frame set, or DATA
%                    is a struct with fields .frames and .frameRate ->
%                    saved as MP4 under results/detected_videos/
%     'evaluation' - DATA is a struct/table of metrics -> saved as .mat
%                    AND, if it contains a figure handle field 'figHandle',
%                    also exported as PNG, under results/evaluation_results/
%
%   FILENAMEHINT is a base name (timestamp and extension are added
%   automatically). CFG is the project config struct.
%
%   Returns the full path of the primary file written.
    timestamp = datestr(now, 'yyyymmdd_HHMMSS');
switch lower(category)
case 'image'
            outDir = cfg.paths.detectedImagesDir;
            outPath = fullfile(outDir, sprintf('%s_%s.png', filenameHint, timestamp));
            imwrite(data, outPath);
case 'video'
            outDir = cfg.paths.detectedVideosDir;
            outPath = fullfile(outDir, sprintf('%s_%s.mp4', filenameHint, timestamp));
if isstruct(data) && isfield(data, 'frames')
                vw = VideoWriter(outPath, 'MPEG-4');
                vw.FrameRate = data.frameRate;
                open(vw);
for f = 1:numel(data.frames)
                    writeVideo(vw, data.frames{f});
end
                close(vw);
else
                error('saveResults:invalidVideoData', ...
'For category "video", DATA must be a struct with fields .frames and .frameRate.');
end
case 'evaluation'
            outDir = cfg.paths.evaluationResultsDir;
            outPath = fullfile(outDir, sprintf('%s_%s.mat', filenameHint, timestamp));

            results = data;
if isstruct(results) && isfield(results, 'figHandle')
                results = rmfield(results, 'figHandle'); % drop graphics object before saving
end
            save(outPath, 'results'); %#ok<NASGU>

if isstruct(data) && isfield(data, 'figHandle') && isgraphics(data.figHandle)
                figPath = fullfile(outDir, sprintf('%s_%s.png', filenameHint, timestamp));
                exportgraphics(data.figHandle, figPath, 'Resolution', 200);
end
otherwise
            error('saveResults:unknownCategory', ...
'Unknown category "%s". Use image, video, or evaluation.', category);
end
    fprintf('  [saved] %s -> %s\n', category, outPath);
end