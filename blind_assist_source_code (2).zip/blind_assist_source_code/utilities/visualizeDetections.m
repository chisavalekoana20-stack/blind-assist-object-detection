function outImg = visualizeDetections(img, bboxes, scores, labels, varargin)
%VISUALIZEDETECTIONS Annotate an image with detection boxes, scores, and
%distance/position hints, returning the annotated image.
%
%   OUTIMG = VISUALIZEDETECTIONS(IMG, BBOXES, SCORES, LABELS) draws
%   bounding boxes with class + confidence labels on IMG.
%
%   OUTIMG = VISUALIZEDETECTIONS(..., 'ShowMinimap', true) additionally
%   overlays a simple left/center/right position indicator per box,
%   useful groundwork for the assistance layer's scene description.
%
%   Name-value options:
%     'LineWidth'    (default 3)
%     'FontSize'     (default 14)
%     'ShowMinimap'  (default false)

    p = inputParser;
    addParameter(p, 'LineWidth', 3);
    addParameter(p, 'FontSize', 14);
    addParameter(p, 'ShowMinimap', false);
    parse(p, varargin{:});
    opts = p.Results;

    if isempty(bboxes)
        outImg = img;
        return;
    end

    annotations = strings(size(labels));
    for k = 1:numel(labels)
        annotations(k) = sprintf('%s (%.0f%%)', string(labels(k)), scores(k) * 100);
    end

    colors = lines(max(numel(labels), 1)) * 255;

    outImg = insertObjectAnnotation(img, 'rectangle', bboxes, cellstr(annotations), ...
        'LineWidth', opts.LineWidth, ...
        'FontSize', opts.FontSize, ...
        'Color', colors);

    if opts.ShowMinimap
        imgWidth = size(img, 2);
        third = imgWidth / 3;
        for k = 1:size(bboxes, 1)
            cx = bboxes(k,1) + bboxes(k,3)/2;
            if cx < third
                pos = 'left';
            elseif cx < 2*third
                pos = 'center';
            else
                pos = 'right';
            end
            outImg = insertText(outImg, [bboxes(k,1), bboxes(k,2) + bboxes(k,4) + 4], ...
                pos, 'BoxOpacity', 0.4, 'FontSize', max(opts.FontSize - 4, 8));
        end
    end
end
